import requests
import re
import json
from typing import Optional, Any, List, Dict
from typing_extensions import TypeAlias, Literal

from ..ff.log_utils import fflog
from ..ff.types import JsonData
from ..defs import MediaRef, VideoIds

ImdbTitleType: TypeAlias = Literal['feature', 'tv_series', 'short', 'tv_episode', 'tv_miniseries',
                                   'tv_movie', 'tv_special', 'tv_short', 'video_game', 'video',
                                   'music_video', 'podcast_series', 'podcast_episode']

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"


class ImdbScraper:

    def __init__(self) -> None:
        self.headers = {"User-Agent": UA}
        self.session = requests.Session()
        # title_type = feature, tv_series, short, tv_episode, tv_miniseries, tv_movie, tv_special, tv_short,
        #              video_game, video,music_video, podcast_series, podcast_episode
        self.url: str = 'https://www.imdb.com/'

    def get_html(self, url: str, params: Optional[Dict[str, Any]] = None) -> Optional[str]:
        req = self.session.get(url, headers=self.headers, params=params)
        if req.status_code != 200:
            return None
        return req.text

    def last_oscars_refs(self,
                         name: str = 'oscar_winner',
                         *,
                         title_type: Optional[ImdbTitleType] = None,
                         ) -> List[MediaRef]:
        params = {
            'sort': 'year,desc',
            'count': 250,
            'groups': name,
        }
        if title_type:
            params['title_type'] = title_type
        html: Optional[str] = self.get_html(f'{self.url}search/title/', params=params)

        pattern = re.compile(r'<script\s+id="__NEXT_DATA__"\s+type="application/json">(.*?)<\/script>', re.DOTALL)
        if html is not None:
            match = pattern.search(html)
            json_object: JsonData = {}

            if match:
                result: str = match.group(1)
                json_object = json.loads(result)

            if json_object:
                data: List[JsonData] = json_object.get("props", {}).get("pageProps", {}).get("searchResults", {}).get("titleResults", {}).get("titleListItems", {})

                return [VideoIds(imdb=it['titleId']).ref('movie') for it in data]

        return []

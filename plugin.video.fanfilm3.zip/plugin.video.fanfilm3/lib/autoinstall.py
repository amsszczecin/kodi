"""Nothing to do, force import `lib`, it's enough."""

# This in not necessary now.
# from lib.kover import autoinstall  # noqa: F401, pylint: disable=W0611

"""
Simple Kodi localized string getter L().
It's extracrted from libka module.

Example
-------

    from kolang import L

    L('localized string')
    L(31000, 'Already localized string')

    # then run kolang.pyz -L en,pl .
    # the first form will change to the second form

Author: rysson <robert.kalinowski@sharkbits.com>
License: MIT
Home: https://github.com/kodi-pl/
"""


from typing import overload, Optional, Union, Any, Dict, TYPE_CHECKING
from typing_extensions import Literal
from pathlib import Path
import re
try:
    from xbmcaddon import Addon
except ModuleNotFoundError:
    # DEBUG & TESTS  (run w/o Kodi)
    if TYPE_CHECKING:
        from xbmcaddon import Addon
    else:
        class Addon:                           # noqa: D101
            def __init__(self, id=None):       # noqa: D107
                pass
            def getLocalizedString(self, v):   # noqa: D102, E301
                return str(v)


_label_getters: Dict[str, 'LabelGetter'] = {}


class LabelGetter:
    """Simple label string getter (like getLocalizedString) for given addon ID."""

    def __init__(self, id: Optional[str] = None) -> None:
        self.id: Optional[str] = id
        self.addon: Addon = None
        self.reset()

    def reset(self) -> None:
        """Recreate addon."""
        self.addon = Addon() if self.id is None else Addon(self.id)

    @overload
    def __call__(self, id: int, string: str) -> str:
        ...

    @overload
    def __call__(self, id: int) -> str:
        ...

    @overload
    def __call__(self, string: str) -> str:
        ...

    def __call__(self, *args: Any) -> str:
        """L(). Get localized string. If there is no ID there string is returned without translation."""
        sid: Optional[int]
        text: str
        if len(args) == 2:
            sid, text = args
        elif len(args) == 1:
            if isinstance(args[0], int):
                sid, text = args[0], ''
            else:
                sid, text = None, args[0]
        else:
            raise TypeError(f'L{args} – incorrect arguments')
        if sid:
            return self.addon.getLocalizedString(sid)
        return text


class KodiLabels:
    """Main Kodi labels translations."""

    # kodi strin.po translation parse regex.
    _rx = re.compile(r'\nmsgctxt "#(?P<id>\d+)"\s*\nmsgid\s+"(?P<en>\\.|[^"]*)"\s*\nmsgstr\s+"(?P<loc>\\.|[^"]*)"')

    def __init__(self, locale: Optional[str] = None) -> None:
        if locale is None:
            locale = self.ui_locale()
        self._translations: Optional[Dict[int, str]] = None
        self._addon: Union[None, Literal[False], Addon] = None
        self.locale: str = locale

    @classmethod
    def ui_locale(cls) -> str:
        """Get current Kodi UI locale."""
        from .ff.locales import kodi_locale
        return kodi_locale()

    def set_locale(self, locale: Optional[str] = None) -> None:
        """Set locale (UI language change)."""
        if locale is None:
            locale = self.ui_locale()
        if locale != self.locale:
            self._translations = None
            self._addon = None

    @property
    def addon(self) -> Optional[Addon]:
        """Get language addon."""
        if self._addon is None:
            try:
                loc = self.locale.lower().replace('-', '_')
                self._addon = Addon(f'resource.language.{loc}')
            except RuntimeError:
                self._addon = False
        return self._addon or None

    @property
    def translations(self) -> Dict[int, str]:
        """Get translations, lazy loading."""
        if self._translations is None:
            if addon := self.addon:
                path = Path(addon.getAddonInfo('path')) / 'resources' / 'strings.po'
                try:
                    with open(path, encoding='utf-8') as f:
                        self._translations = {int(mch['id']): mch['loc'] or mch['en']
                                              for mch in self._rx.finditer(f.read())}
                except IOError:
                    self._translations = {}
            else:
                self._translations = {}
        return self._translations

    def label(self, id: int) -> str:
        """Get localized label."""
        return self.translations.get(id, f'#{id}')

    def get(self, id: int, default: Optional[str] = None) -> Optional[str]:
        """Get localized label with default."""
        return self.translations.get(id, default)

    def __getitem__(self, key: int) -> str:
        """Get localized label, dict-like access: KodiLabels('pl-PL')[123]."""
        return self.translations[key]

    __call__ = label


def get_label_getter(id: Optional[str] = None) -> LabelGetter:
    """
    Return label string getter (like getLocalizedString) for given addon ID.
    """
    try:
        return _label_getters[id].getter
    except KeyError:
        _label_getters[id] = getter = LabelGetter(id)
    return getter


def reset() -> None:
    """Reset all getters."""
    for getter in _label_getters.values():
        getter.reset()


#: Language label getter (translation) for current itself.
L = get_label_getter()

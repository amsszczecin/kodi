from typing import Optional, Any, Tuple, Dict, Callable, Type, NamedTuple
from threading import Thread, Condition
from queue import Queue
from xbmcgui import WindowXML, WindowXMLDialog
from wrapt.wrappers import ObjectProxy
from ..ff import control
from ..ff.log_utils import fflog


Args = Tuple[Any, ...]
KwArgs = Dict[str, Any]


class WindowCommand(NamedTuple):
    method: Callable
    args: Args
    kwargs: KwArgs


class WindowThread(Thread):
    """Thread to call window's doModal() in thread (non blocking)."""

    def __init__(self,
                 win_class: Type,
                 name: Optional[str] = None,
                 args: Args = (),
                 kwargs: KwArgs = {},  # noqa: B006
                 ) -> None:
        super().__init__(name=name)
        #: Window class to create the window.
        self.win_class: Type = win_class
        #: Arguments for window create.
        self.args: Args = args
        #: Keyword arguments for window create.
        self.kwargs: KwArgs = kwargs
        #: The window.
        self.win: WindowXML = None
        #: Thread condition variable for window creation.
        self.win_ready = Condition()
        #: Window commands (doModal) queue.
        self.win_commands = Queue()

    def run(self) -> None:
        """Do job. Main thread proc."""
        fflog(f'••• [TH] create win {self.win_class}, {self.args}, {self.kwargs}')
        self.win = self.win_class(*self.args, **self.kwargs)
        try:
            fflog('••• [TH] notify')
            with self.win_ready:
                self.win_ready.notify()
            while True:
                fflog('••• [TH] wait for command')
                cmd: WindowCommand = self.win_commands.get()
                fflog(f'••• [TH] {cmd=}')
                if not cmd:
                    break
                cmd.method(*cmd.args, **cmd.kwargs)
                self.win_commands.task_done()
        finally:
            fflog('••• [TH] close')
            self.win.close()
        fflog('••• [TH] finished')

    def command(self, method: Callable, *args, **kwargs) -> None:
        """Postpone window method call."""
        self.win_commands.put(WindowCommand(method, args, kwargs))


class _WindowMetaClass(type):
    """Base Window meta-class to modify __init__ arguments."""

    def __call__(self, *args, **kwargs):
        return super().__call__(*args, **kwargs).__wrapped__


class BaseWindow(WindowXML):

    def __new__(cls, xmlFilename: str = None, scriptPath: str = control.addonPath, *args, **kwargs):
        if xmlFilename is None:
            xmlFilename = cls.XML
        obj = super().__new__(cls, xmlFilename, scriptPath, *args)
        obj.__init__(xmlFilename, scriptPath, *args, **kwargs)
        return ObjectProxy(obj)  # to avoid __init__ call, _WindowMetaClass will remove ObjectProxy

    def add_items(self, control, items):
        control = self.getControl(control)
        control.reset()
        control.addItems(items)


class BaseDialog(WindowXMLDialog):

    def __new__(cls, xmlFilename: str = None, scriptPath: str = control.addonPath, *args,
                modal: bool = True, **kwargs) -> 'BaseDialog':
        if xmlFilename is None:
            xmlFilename = cls.XML
        if not modal:
            # for non-blocking dialogs, window is created in thread
            th: WindowThread = WindowThread(super().__new__, args=(cls, xmlFilename, scriptPath, *args))
            fflog(f'••• start thread {th}')
            th.start()
            with th.win_ready:
                if not th.win:
                    fflog('••• wait for window')
                    th.win_ready.wait()
            obj = th.win
            obj._thread: WindowThread = th
        else:
            obj = super().__new__(cls, xmlFilename, scriptPath, *args)
            obj._thread: WindowThread = None
        fflog('••• init')
        obj.__init__(xmlFilename, scriptPath, *args, **kwargs)
        fflog('••• created')
        return ObjectProxy(obj)  # to avoid __init__ call, _WindowMetaClass will remove ObjectProxy

    def __init__(self, *args, **kwargs) -> None:
        """Useless, because WindowXMLDialog uses __new__ only."""
        pass

    def close(self) -> None:
        if self._thread:
            fflog('••• postpone exit')
            self._thread.win_commands.put(None)
        fflog('••• close')
        super().close()
        fflog('••• finished')

    def doModal(self) -> None:
        """Ececute the window. Call doModal direct (modal) or in thread (modeless)."""
        if self._thread:
            self.show()
            fflog(f'••• postopne {self.doModal}')
            self._thread.command(super().doModal)
            fflog(f'••• snet {self.doModal}')
        else:
            super().doModal()

    def is_modal(self) -> bool:
        """Return True if dialog is modal."""
        return not self._thread

    def destroy(self) -> None:
        """Close and clean up."""
        self.close()
        if self._thread:
            self._thread.join()

    def add_items(self, control, items):
        control = self.getControl(control)
        control.reset()
        control.addItems(items)

BEGIN;

DROP TABLE IF EXISTS trakt_playback;

COMMIT;

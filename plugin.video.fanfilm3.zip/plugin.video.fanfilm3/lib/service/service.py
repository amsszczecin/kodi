

ans = 44


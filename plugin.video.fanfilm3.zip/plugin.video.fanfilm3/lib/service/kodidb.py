"""
Direct access to Kodi MyVideo*.db.

Use carefully.
"""

import re
from pathlib import Path
from contextlib import contextmanager
from sqlite3 import connect as db_connect, Connection, Cursor, OperationalError
from time import sleep
from urllib.parse import parse_qsl
import json
from typing import Optional, List, Dict, Iterator, Mapping, Sequence
from typing_extensions import Literal, cast
from attrs import frozen, field
from ..defs import MediaRef, RefType, VideoIds, ItemList
from ..ff.types import JsonResult, JsonData, Params
from ..ff.db import Lock
from ..indexers.defs import VideoSequenceMixin
from ..ff.log_utils import fflog
from ..ff.control import plugin_url
from const import const

from xbmcvfs import translatePath, File
from xbmc import executeJSONRPC
from ..kodi import version as kodi_ver



QueryParams = Dict[str, str]


@frozen(kw_only=True)
class KodiVideoInfo:
    """Played/playing video DB row."""

    # -- in SELECT order, see KodiVideoDB.get_plays()

    #: Media reference.
    ref: MediaRef
    #: files.fileId
    fid: Optional[int] = None
    #: bookmark.bookmarkId
    bid: Optional[int] = None
    #: files.strFilename
    fname: str = ''
    #: files.playCount
    play_count: int = 0
    #: Last played at.
    played_at: str = ''
    #: bookmark.timeInSeconds
    time_s: float = 0
    #: bookmark.totalTimeInSeconds
    total_s: float = 0
    #: Parsed query from `fname`
    params: QueryParams = field(factory=dict)

    @property
    def percent(self) -> Optional[float]:
        """Progress in percent (0..100)."""
        if self.total_s:
            return 100 * self.time_s / self.total_s
        return None

    @property
    def imdb(self) -> Optional[str]:
        """IMDB ID from video FF link query."""
        return self.params.get('imdb')

    @property
    def tmdb(self) -> Optional[str]:
        """TMDB ID from video FF link query."""
        return self.params.get('tmdb')

    @property
    def has_progress(self) -> bool:
        """File has progress (is playing)."""
        return bool(self.total_s)

    @property
    def fake(self) -> bool:
        """True if info is fake."""
        return self.fid is None


class VideoInfoList(VideoSequenceMixin[KodiVideoInfo], list):
    pass


#: Kodi Video Database version, see: https://kodi.wiki/view/Databases#Database_Versions
vdb_ver: str = {
    19: '119',
    20: '121',
    21: '131',
}.get(kodi_ver, '121')


class KodiVideoDB:
    """Kodi MyVideo*.db."""

    VTYPES: Dict[str, RefType] = {
        'tvshow': 'show',
    }
    RPC_LIST_METHODS = {
        'movie': 'VideoLibrary.GetEpisodes',
        'show': 'VideoLibrary.GetTVShows',
        'tvshow': 'VideoLibrary.GetTVShows',
        'season': 'VideoLibrary.GetSeasons',
        'episode': 'VideoLibrary.GetEpisodes',
    }

    _plugin = plugin_url.rstrip('/')
    _old_plugin = 'plugin://plugin.video.fanfilm'
    _old_plugin_pattern = _old_plugin if _old_plugin == _plugin else fr'(?:{_plugin}|{_old_plugin})'
    _rx_movie_link = re.compile(fr'{_plugin}/play/movie/(?P<dbid>\d+)\b(?:\?.*)?'
                                fr'|{_old_plugin_pattern}?.*\btmdb=(?P<tmdb>\d+).*')
    _rx_episode_link = re.compile(fr'{_plugin}/play/tvshow/(?P<dbid>\d+)/(?P<season>\d+)/(?P<episode>\d+)(?:\?.*)?'
                                  fr'|{_old_plugin_pattern}?.*\btmdb=(?P<old_tmdb>\d+)?&season=(?P<old_season>\d+)&episode=(?P<old_episode>\d+).*')

    def __init__(self, *, path: Optional[Path] = None, echo: Optional[bool] = None) -> None:
        echo = const.dev.db.echo if echo is None else bool(echo)
        #: Path to video DB.
        self.path: Path = Path(translatePath('special://database')) / f'MyVideos{vdb_ver}.db' if path is None else path
        #: Connection to video DB.
        self._conn: Optional[Connection] = None
        #: Lack for multithread access.
        self.lock = Lock()
        #: Debug echo queries.
        self._echo: bool = not echo  # Force change echo detection.
        # Set echo proprery (change forced).
        self.echo = echo
        #: JSON-RPC message id.
        self._jsonrpc_id = 1

    @contextmanager
    def connection(self) -> Iterator[Connection]:
        """Open connection to he DB or use existing one."""
        new_conn: bool = not self._conn
        if not self._conn:
            self._conn = db_connect(f'file:{self.path}?mode=ro', uri=True, check_same_thread=False, timeout=10)
            self._update_echo()
        try:
            yield self._conn
        finally:
            try:
                if new_conn:
                    self._conn.close()
            finally:
                if new_conn:
                    self._conn = None

    @contextmanager
    def cursor(self) -> Iterator[Cursor]:
        """Create DB cursor."""
        with self.lock:
            with self.connection() as conn:
                cur = conn.cursor()
                try:
                    yield cur
                finally:
                    try:
                        cur.connection.commit()
                    finally:
                        cur.close()

    @property
    def echo(self) -> bool:
        """Echo queries (debug)."""
        return self._echo

    @echo.setter
    def echo(self, echo: bool) -> None:
        """Echo queries (debug)."""
        echo = bool(echo)
        if self._echo != echo:
            self._echo = echo
            self._update_echo()

    def _update_echo(self) -> None:
        """Echo queries (debug)."""
        if self._conn:
            if self._echo:
                self._conn.set_trace_callback(self._log_statement)
            else:
                self._conn.set_trace_callback(None)

    def _log_statement(self, stmt: str):
        """Echo SQL statement."""
        fflog(f'(DB:{self.path.stem}) \033[38;5;244m {stmt!r} \033[0m', stack_depth=2)

    def get_plays(self, *, tries: int = 3) -> List[KodiVideoInfo]:
        """Return list of played or playing videos."""

        def make_ref(fname: str, params: Mapping[str, str]) -> Optional[MediaRef]:
            if '/play/movie/' in fname:
                return MediaRef.movie(int(fname.partition('?')[0].rpartition('/')[2]))
            if '/play/tvshow/' in fname:
                return MediaRef.tvshow(*map(int, fname.partition('?')[0].rsplit('/', 3)[-3:]))
            if not ({'tmdb', 'season', 'episode'} - params.keys()):  # not set-keys means all keys exists
                return MediaRef.tvshow(int(params['tmdb']), int(params['season']), int(params['episode']))
            if 'tmdb' in params:
                return MediaRef.movie(int(params['tmdb']))
            return None

        last_exc: Optional[Exception] = None
        for cnt in range(tries):
            try:
                with self.cursor() as cur:
                    cur.execute('SELECT'
                                ' f.idFile, b.idBookmark, strFilename, playCount, timeInSeconds, totalTimeInSeconds'
                                ' FROM files AS f LEFT JOIN bookmark AS b ON b.idFile == f.idFile'
                                f" WHERE strFilename LIKE '{plugin_url}%'")
                    # row[2] - in order in SELECT above, it's `strFilename`
                    return VideoInfoList(KodiVideoInfo(ref=ref, fid=row[0], bid=row[1], fname=row[2], play_count=row[3],
                                                       time_s=row[4], total_s=row[5], params=params)
                                         for row in cur.fetchall()
                                         if ((fname := row[2])
                                             and (params := dict(parse_qsl(fname.partition('?')[2]))) is not None
                                             and (ref := make_ref(fname, params))))
            except OperationalError as exc:
                last_exc = exc
                if cnt + 1 < tries:
                    sleep(.1)
        fflog(f'Access to kodi DB failed: {last_exc}')
        return VideoInfoList()

    def get_play(self, ref: MediaRef, *, tries: int = 3, old_fanfilm: bool = True) -> Optional[KodiVideoInfo]:
        """Return played or playing video by ref."""

        plugin = plugin_url.rstrip('/')
        if ref.is_movie:
            link = f'{plugin}/play/movie/{ref.dbid}'
            where = f"strFilename = '{link}' OR strFilename LIKE '{link}?%'"
        elif ref.is_episode:
            link = f'{plugin}/play/tvshow/{ref.dbid}/{ref.season}/{ref.episode}'
            where = f"strFilename = '{link}' OR strFilename LIKE '{link}?%'"
        else:
            return None

        select = ('SELECT f.idFile, b.idBookmark, strFilename, playCount, timeInSeconds, totalTimeInSeconds'
                  ' FROM files AS f LEFT JOIN bookmark AS b ON b.idFile == f.idFile')

        row = None
        for cnt in range(tries):
            try:
                with self.cursor() as cur:
                    cur.execute(f'{select} WHERE {where}')
                    row = cur.fetchone()
                    fflog(f'[KodiDB] new {where!r}, {row=}')
                    if row is None and old_fanfilm:
                        vids = VideoIds.from_dbid(ref.dbid)
                        if vids and vids.tmdb:
                            if ref.is_movie:
                                where = f"strFilename LIKE '{plugin}/?action=play%&tmdb={vids.tmdb}'"
                            elif ref.is_episode:
                                where = f"strFilename LIKE '{plugin}/?action=play%&tmdb={vids.tmdb}&season={ref.season}&episode={ref.episode}'"
                            cur.execute(f'{select} WHERE {where}')
                            row = cur.fetchone()
                            fflog(f'[KodiDB] old {where!r}, {row=}')
                break
            except OperationalError:
                if cnt + 1 < tries:
                    sleep(.1)
        if row:
            fid, bid, fname, play_count, time_s, total_s = row
            return KodiVideoInfo(ref=ref, fid=fid, bid=bid, fname=fname, play_count=play_count, time_s=time_s, total_s=total_s,
                                 params=dict(parse_qsl(fname.partition('?')[2])))
        return None

    def get_play_by_kodi_id(self, type: Literal['movie', 'tvshow', 'show', 'season', 'episode'], id: int, *,
                            tries: int = 3, read_strm: bool = False) -> Optional[KodiVideoInfo]:
        """Return played or playing video by kodi id. Accepts FF and kodi types."""
        return self.rpc_get_play_by_kodi_id(type=type, id=id, tries=tries, read_strm=read_strm)
        return self.direct_get_play_by_kodi_id(type=type, id=id, tries=tries, read_strm=read_strm)

    def direct_get_play_by_kodi_id(self, type: Literal['movie', 'tvshow', 'show', 'season', 'episode'], id: int, *,
                                   tries: int = 3, read_strm: bool = False) -> Optional[KodiVideoInfo]:
        """Return played or playing video by kodi id. Accepts FF and kodi types."""
        vtype = self.VTYPES.get(type, cast(RefType, type))
        for cnt in range(tries):
            try:
                with self.cursor() as cur:
                    ref: Optional[MediaRef] = None
                    service = uid = None
                    tv_service = tv_uid = None
                    season = episode = None
                    strm = None
                    fname = ''
                    play_count = time_s = total_s = 0
                    played_at = ''
                    bid = fid = 0
                    if vtype == 'movie':
                        query = ('SELECT'
                                 '  u.type AS service, u.value AS uid, c22 AS strm,'
                                 '  f.playCount, f.lastPlayed, b.timeInSeconds, b.totalTimeInSeconds,'
                                 '  f.idFile, b.idBookmark'
                                 ' FROM movie as m'
                                 ' LEFT JOIN uniqueid AS u ON m.idMovie = u.media_id AND u.media_type = \'movie\''
                                 ' LEFT JOIN files AS f ON m.idFile = f.idFile'
                                 ' LEFT JOIN bookmark as b ON b.idFile = f.idFile'
                                 ' WHERE idMovie = {id}')
                        cur.execute(query.format(id=id))
                        if row := cur.fetchone():
                            service, uid, strm, play_count, played_at, time_s, total_s, fid, bid = row
                    elif vtype == 'show':
                        query = ('SELECT'
                                 '  ut.type AS tv_service, ut.value AS tv_uid'
                                 ' FROM tvshow AS s'
                                 ' LEFT JOIN uniqueid AS ut ON s.idShow = ut.media_id AND ut.media_type = \'tvshow\''
                                 ' WHERE idShow = {id}')
                        cur.execute(query.format(id=id))
                        if row := cur.fetchone():
                            service, uid = row
                    elif vtype == 'season':
                        query = ('SELECT'
                                 '  ut.type AS tv_service, ut.value AS tv_uid, z.idSeason as season'
                                 ' FROM seasons AS z'
                                 ' LEFT JOIN tvshow AS s ON z.idShow = s.idShow'
                                 ' LEFT JOIN uniqueid AS ut ON s.idShow = ut.media_id AND ut.media_type = \'tvshow\''
                                 ' WHERE z.idSeason = {id}')
                        cur.execute(query.format(id=id))
                        if row := cur.fetchone():
                            tv_service, tv_uid, season = row
                    elif vtype == 'episode':
                        query = ('SELECT'
                                 '  u.type AS service, u.value AS uid, ut.type AS tv_service, ut.value AS tv_uid,'
                                 '  e.c12 AS season, e.c13 AS epsiode, e.c18 AS strm,'
                                 '  f.playCount, f.lastPlayed, b.timeInSeconds, b.totalTimeInSeconds,'
                                 '  f.idFile, b.idBookmark'
                                 ' FROM episode as e'
                                 ' LEFT JOIN uniqueid AS u ON e.c20 = u.uniqueid_id'
                                 ' LEFT JOIN tvshow AS s ON e.idShow = s.idShow'
                                 ' LEFT JOIN uniqueid AS ut ON s.c12 = ut.uniqueid_id AND ut.media_type = \'tvshow\''
                                 ' LEFT JOIN files AS f ON e.idFile = f.idFile'
                                 ' LEFT JOIN bookmark as b ON b.idFile = f.idFile'
                                 ' WHERE idEpisode = {id}')
                        cur.execute(query.format(id=id))
                        if row := cur.fetchone():
                            service, uid, tv_service, tv_uid, season, episode, strm, play_count, played_at, time_s, total_s, fid, bid = row
                            season, episode = int(season), int(episode)
                    else:
                        return None
                    if tv_service and tv_uid:
                        try:
                            vid = VideoIds(**{tv_service: tv_uid})
                            ref = MediaRef.tvshow(vid.dbid, season, episode)
                        except TypeError:
                            pass
                    if not ref and service and uid:
                        try:
                            vid = VideoIds(**{service: uid})
                            ref = MediaRef(vtype, vid.dbid)  # denormalized
                        except TypeError:
                            return None
                    if not ref and strm:
                        # fallback: read strm file to get play link
                        try:
                            with File(strm) as f:
                                fname = f.read().strip()
                        except IOError:
                            return None  # no ref and no strm (no FF link)
                        if vtype == 'movie':
                            rx = self._rx_movie_link
                        elif vtype == 'episode':
                            rx = self._rx_episode_link
                        else:
                            return None  # should never catch, there is no strm fiel for season or show
                        try:
                            with File(strm) as f:
                                fname = f.read().strip()
                            if mch := rx.fullmatch(fname):
                                print(mch.groupdict())
                                mtype = 'movie' if vtype == 'movie' else 'show'
                                if mch['dbid']:
                                    ref = MediaRef(mtype, *map(int, mch.group('dbid', 'season', 'episode')))
                                else:  # old (stable2023, FF2)
                                    ref = MediaRef(mtype, VideoIds(tmdb=int(mch['old_tmdb'])).dbid, *map(int, mch.group('old_season', 'old_episode')))
                        except IOError:
                            pass
                    elif read_strm and strm:
                        try:
                            with File(strm) as f:
                                fname = f.read().strip()
                        except IOError:
                            pass

                    if ref:
                        return KodiVideoInfo(ref=ref, fid=fid, bid=bid, fname=fname,
                                             play_count=play_count, played_at=played_at, time_s=time_s, total_s=total_s)
            except OperationalError:
                if cnt + 1 < tries:
                    sleep(.1)
        return None

    def rpc_get_play_by_kodi_id(self, type: Literal['movie', 'tvshow', 'show', 'season', 'episode'], id: int, *,
                                tries: int = 3, read_strm: bool = False) -> Optional[KodiVideoInfo]:
        """Return played or playing video by kodi id. Accepts FF and kodi types."""
        vtype = self.VTYPES.get(type, cast(RefType, type))
        # method = self.RPC_LIST_METHODS[type]
        if vtype == 'movie':
            data = video_db.rpc_object('VideoLibrary.GetMovieDetails', params={'movieid': id},
                                       fields=['uniqueid', 'playcount', 'lastplayed', 'resume', 'runtime'])
        elif vtype == 'show':
            data = video_db.rpc_object('VideoLibrary.GetTVShowDetails', params={'tvshowid': id},
                                       fields=['uniqueid'])
        elif vtype == 'season':
            data = video_db.rpc_object('VideoLibrary.GetSeasonDetails', params={'seasonid': id},
                                       fields=['uniqueid', 'season', 'tvshowid'])
        elif vtype == 'episode':
            data = video_db.rpc_object('VideoLibrary.GetEpisodeDetails', params={'episodeid': id},
                                       fields=['uniqueid', 'playcount', 'lastplayed', 'resume', 'runtime', 'season', 'episode', 'tvshowid'])
        else:
            return None
        if 'uniqueid' not in data:
            return None

        vid = VideoIds.from_ids(data['uniqueid'])
        if vtype in ('season', 'episode'):
            tvdata = video_db.rpc_object('VideoLibrary.GetTVShowDetails', params={'tvshowid': data['tvshowid']}, fields=['uniqueid'])
            tv_vid = VideoIds.from_ids(tvdata['uniqueid'])
            ref = MediaRef.tvshow(tv_vid.dbid, data.get('season'), data.get('episode'))
        else:
            ref = MediaRef(vtype, vid.dbid)

        time_s = total_s = 0
        if resume := data.get('resume'):
            time_s = resume['position']
            total_s = resume['total']
        fflog(f'_____DB_____\n{data = }')
        return KodiVideoInfo(ref=ref, play_count=data.get('playcount', 0), played_at=data.get('lastplayed', ''), time_s=time_s, total_s=total_s)

    def rpc(self, method: str, *, params: Optional[Params] = None, fields: Sequence[str] = ()) -> JsonResult:
        """Call remote procedure (JSONRPC)."""
        msg_id, self._jsonrpc_id = self._jsonrpc_id, self._jsonrpc_id + 1
        params = dict(params or {})
        req = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params,
            'id': msg_id,
        }
        # TODO: sort
        # TODO: filter
        # TODO: limits
        if fields:
            params['properties'] = tuple(fields)
        data = json.loads(executeJSONRPC(json.dumps(req)))
        fflog(f'................  {data}')
        return data

    def rpc_list(self, method: str, *, params: Optional[Params] = None, fields: Sequence[str] = (), return_type: Optional[str] = None) -> Sequence[JsonData]:
        """Call remote procedure (JSONRPC)."""
        data = self.rpc(method=method, params=params, fields=fields)
        if isinstance(data, Mapping) and isinstance((result := data.get('result')), Mapping):
            if return_type is None:
                return_type = next(iter(result.keys() - {'limits'}), None)
                if return_type is None:
                    return []
            # if limits := result.get('limits'):
            #     end, start, total = limits['end'], limits['start'], limits['total']
            return result[return_type]
        return []

    def rpc_object(self, method: str, *, params: Optional[Params] = None, fields: Sequence[str] = (), return_type: Optional[str] = None) -> JsonData:
        """Call remote procedure (JSONRPC)."""
        data = self.rpc(method=method, params=params, fields=fields)
        if isinstance(data, Mapping) and isinstance((result := data.get('result')), Mapping):
            if return_type is None:
                return_type = next(iter(result.keys() - {'limits'}), None)
                if return_type is None:
                    return {}
            return result[return_type]
        return {}


video_db = KodiVideoDB()


if __name__ == '__main__':
    def main_test():
        from pprint import pprint
        from ..ff.cmdline import DebugArgumentParser, parse_ref

        p = DebugArgumentParser(dest='cmd')
        p.add_argument('--dbpath', type=Path, default=Path('~/.kodi/userdata/Database').expanduser() / f'MyVideos{vdb_ver}.db',
                       help='path to Kodi MyVideos.db')
        with p.with_subparser('ref') as pp:
            pp.add_argument('media', nargs='?', type=parse_ref, help='media: movie/ID or show/ID/SEASON/EPISODE')
        with p.with_subparser('id') as pp:
            pp.add_argument('type', choices=('movie', 'show', 'season', 'episode'), help='kodi media type')
            pp.add_argument('id', type=int, help='kodi dbid')
            pp.add_argument('--read-strm', action='store_true', help='force read strm file')
        args = p.parse_args()

        kodidb = KodiVideoDB(path=args.dbpath)
        if args.cmd == 'ref':
            ref: MediaRef = args.media
            if ref:
                print(kodidb.get_play(ref))
            else:
                pprint(kodidb.get_plays())
        elif args.cmd == 'id':
            print(kodidb.get_play_by_kodi_id(args.type, args.id, read_strm=args.read_strm))

    main_test()

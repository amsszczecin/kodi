from . import control
# from .log_utils import fflog
from .db_connection_manager import connection_manager
from .debug import log_exception
import time

# Cache dla zapytań do bazy danych
view_cache = {}


def addView(content):
    try:
        skin = control.skin
        record = (skin, content, str(control.getCurrentViewId()))
        control.make_dir(control.dataPath)
        dbcon = connection_manager.get_connection("views", control.viewsFile)
        dbcur = dbcon.cursor()
        dbcur.execute(
            "CREATE TABLE IF NOT EXISTS views ("
            "skin TEXT, "
            "view_type TEXT, "
            "view_id TEXT, "
            "UNIQUE(skin, view_type)"
            ");"
        )
        dbcur.execute(
            "DELETE FROM views WHERE skin = '%s' AND view_type = '%s'"
            % (record[0], record[1])
        )
        dbcur.execute("INSERT INTO views Values (?, ?, ?)", record)
        dbcon.commit()

        viewName = control.infoLabel("Container.Viewmode")
        skinName = control.addon(skin).getAddonInfo("name")
        skinIcon = control.addon(skin).getAddonInfo("icon")

        control.infoDialog(viewName, heading=skinName, sound=True, icon=skinIcon)
    except Exception:
        log_exception()
        return


def setView(content, viewDict=None):
    skin = control.skin

    if viewDict:
        # czy tu nie potrzeba dodatkowego czasu oczekiwania ?
        control.execute("Container.SetViewMode(%s)" % str(viewDict[skin]))
        return

    if True:
        view = None
        record = (skin, content)
        # Użycie cache, jeżeli widok jest już znany
        if record in view_cache:
            view = view_cache[record]
        else:
            # próba pobrania widoku z bazy
            try:
                dbcon = connection_manager.get_connection("views", control.viewsFile)
                dbcur = dbcon.cursor()
                dbcur.execute(
                    "SELECT * FROM views WHERE skin = '%s' AND view_type = '%s'"
                    % (record[0], record[1])
                )
                view_row = dbcur.fetchone()
                view = view_row[2] if view_row else None
                # Zapisanie widoku do cache
                view_cache[record] = view
            except Exception:
                # log_exception()  # logować, czy nie?
                pass

        if view is not None:
            # zazwyczaj jest potrzebny dodatkowy czas
            for _ in range(50):  # zakładam max 500 ms - czy nie za mało?
                time.sleep(0.01)
                if control.condVisibility("Container.Content(%s)" % content):
                    break
            # fflog(f'[views.py] {i=!r}')  # do testów
            if control.condVisibility("Container.Content(%s)" % content):
                control.execute("Container.SetViewMode(%s)" % str(view))

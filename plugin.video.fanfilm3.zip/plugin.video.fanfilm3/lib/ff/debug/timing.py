"""Simple timing utilities."""

import sys
from time import monotonic
from functools import update_wrapper
from inspect import iscoroutinefunction
from typing import Optional, Union, TextIO, ContextManager, Callable, TypeVar
from typing_extensions import ParamSpec, overload
from ...ff.log_utils import fflog

P = ParamSpec('P')
T = TypeVar('T')
R = TypeVar('R')


@overload
def logtime(wrapped: Callable[P, R], *, name: Optional[str] = None, file: TextIO = sys.stdout, ff: bool = True) -> Callable[P, R]: ...


@overload
def logtime(wrapped: None = None, *, name: Optional[str] = None, file: TextIO = sys.stdout, ff: bool = True) -> ContextManager: ...


def logtime(wrapped: Optional[Callable[P, R]] = None, *, name: Optional[str] = None, file: TextIO = sys.stdout, ff: bool = True) -> Union[ContextManager, Callable[P, R]]:
    """Print timing log."""
    class LogTiming:

        def __init__(self, *, name: Optional[str] = None, file: TextIO = sys.stdout, ff: bool = ff):
            self.wrapped: Callable = None
            self.name: str = name
            self.file: TextIO = file
            self.fflog: bool = ff
            self.t: float = 0

        def __call__(self, wrapped):
            async def awrapper(*args, **kwargs):
                return await self.acall(*args, **kwargs)

            def swrapper(*args, **kwargs):
                return self.call(*args, **kwargs)

            if iscoroutinefunction(wrapped):
                wrapper = awrapper
            else:
                wrapper = swrapper
            self.wrapped = wrapped
            update_wrapper(wrapper, self.wrapped)
            return wrapper

        async def acall(self, *args, **kwargs):
            """Log async call time consumption."""
            t = monotonic()
            try:
                result = await self.wrapped(*args, **kwargs)
            finally:
                t = monotonic() - t
                self.log(t, f'async call {self.wrapped.__qualname__}()')
            return result

        def call(self, *args, **kwargs):
            """Log call time consumption."""
            t = monotonic()
            result = self.wrapped(*args, **kwargs)
            t = monotonic() - t
            self.log(t, f'call {self.wrapped.__qualname__}()')
            return result

        def __enter__(self):
            self.t = monotonic()
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            t = monotonic() - self.t
            self.log(t, 'with statement')

        async def __aenter__(self):
            self.t = monotonic()
            return self

        async def __aexit__(self, exc_type, exc_value, traceback):
            t = monotonic() - self.t
            self.log(t, 'async with statement')

        def log(self, t, funcname):
            if self.name is not None:
                funcname = self.name
            if self.fflog:
                fflog(f'Time of {funcname} is {t:.3f}')
            else:
                print(f'Time of {funcname} is {t:.3f}', file=self.file)

    obj = LogTiming(name=name, file=file)

    if wrapped is None:   # with statement or decorator with arguments
        return obj
    return obj(wrapped)   # decorator without arguments

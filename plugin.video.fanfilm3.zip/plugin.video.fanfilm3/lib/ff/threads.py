"""
Our wrapper for threading.Thread.

Adds result value, on_finished callbacks (rx. to clean DB connection).
"""

from sys import version_info as PY
from time import monotonic
from threading import Thread as _Thread, local as _local, Event as _Event
from threading import Lock  # noqa: F401
from typing import Optional, Any, Set, Iterable, Mapping, Callable
from typing_extensions import Self, TypeAlias

from .kotools import Monitor
from const import const

ThreadOnFinished: TypeAlias = Callable[[], None]

# Safe future timestamp (signed 32-bit minus more then one day).
MAX_TIMESTAMP = 2**31 - 100000


class local(_local):
    """threading.local wrapper."""


class Event(_Event):
    """threading.Event wrapper."""

    def wait(self, timeout: Optional[float] = None, *, monitor: Optional[Monitor] = None) -> bool:
        """Block until the internal flag is true. See: threading.Event."""
        if monitor is None:
            monitor = Monitor()
        end = MAX_TIMESTAMP if timeout is None else monotonic() + timeout
        while (delta := end - monotonic()) > 0 and not monitor.abortRequested():
            if super().wait(min(delta, const.tune.event_step)):
                return True
        return False
        # while not self.is_set() and (delta := end - monotonic()) > 0:
        #     xsleep(delta, cancel_event=self)
        # return self.is_set()


class Thread(_Thread):
    """threading.Thread wrapper."""

    def __init__(self,
                 group: None = None,
                 target: Optional[Callable[..., Any]] = None,
                 name: Optional[str] = None,
                 args: Iterable[Any] = (),
                 kwargs: Optional[Mapping[str, Any]] = None,
                 *,
                 daemon: Optional[bool] = None,
                 on_finished: Optional[ThreadOnFinished] = None,
                 ) -> None:
        super().__init__(group=group, target=target, name=name, args=args, kwargs=kwargs, daemon=daemon)
        if PY < (3, 10):
            if name is None and callable(target):
                self._name = f'{self._name} ({target.__name__})'
        self._local: Optional[local] = None
        self.result: Any = None
        self.on_finished: Set[ThreadOnFinished] = set()
        if on_finished is not None:
            self.on_finished.add(on_finished)

        # force override run() to catch return value
        def run(self: Self):
            self.result = cls_run(self)
            for cb in self.on_finished:
                cb()

        cls_run = self.__class__.run
        self.__class__.run = run

    def run(self) -> Any:  # taken from PY (3.8-3.12)
        """Method representing the thread's activity.

        You may override this method in a subclass. The standard run() method
        invokes the callable object passed to the object's constructor as the
        target argument, if any, with sequential and keyword arguments taken
        from the args and kwargs arguments, respectively.

        """
        try:
            if self._target is not None:
                return self._target(*self._args, **self._kwargs)
        finally:
            # Avoid a refcycle if the thread is running a function with
            # an argument that has a member that points to the thread.
            del self._target, self._args, self._kwargs

    @property
    def local(self) -> local:
        """Returns threading.local() varaibles as class local instance."""
        if self._local is None:
            self._local = local()
        return self._local


if __name__ == '__main__':
    class MT(Thread):
        def run(self):
            loc.__dict__.setdefault('a', 42)
            print(42, id(loc), loc.__dict__)
            return 42

    class A:
        def print44(self, a=1, b=2):
            loc.__dict__.setdefault('a', 44)
            print(f'44: {a=}, {b=}', id(loc), loc.__dict__)
            return 44

    loc = _local()
    t1 = MT()
    t2 = Thread(target=A().print44, args=(1, 2))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print(t1.name, t2.name)
    print(t1.result, t2.result)

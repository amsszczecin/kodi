# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from typing import Optional, Union, Tuple, Iterator, ClassVar
from typing_extensions import Protocol
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from xbmcvfs import translatePath, exists, mkdirs, File, makeLegalFilename
from xbmc import executebuiltin
from xbmcgui import Dialog

from .anypath import APath
from .item import FFItem
from .log_utils import fflog
from .settings import settings
from .routing import url_for
from .info import ffinfo
from ..defs import MediaRef
from ..main import play_movie, play_tvshow
from ..kolang import L
from const import const


class KodiWritableFile(Protocol):
    def write(self, buffer: Union[str,  bytes,  bytearray]) -> bool: ...
    def close(self) -> None: ...


class DummyFile:

    def write(self, buffer: Union[str,  bytes,  bytearray]) -> bool:
        return True

    def close(self) -> None:
        pass


class LibTools:
    """Base class for library tools"""

    _DEBUG_FOLDER: ClassVar[Optional[str]] = None

    @property
    def movies_dir(self) -> APath:
        if self._DEBUG_FOLDER:
            return APath(self._DEBUG_FOLDER) / 'Movies'
        return APath(translatePath(settings.getString('library.movie')))

    @property
    def tv_dir(self) -> APath:
        if self._DEBUG_FOLDER:
            return APath(self._DEBUG_FOLDER) / 'TVShows'
        return APath(translatePath(settings.getString('library.tv')))

    def item_title(self, item: FFItem) -> str:
        """Make a single catalog for specific FFItem"""
        ref = item.ref
        vtag = item.vtag
        if ref.season:  # season or episode
            if title := vtag.getEnglishTvShowTitle() or vtag.getTVShowTitle():
                return title
        return vtag.getEnglishTitle() or vtag.getTitle()

    def item_path_and_title(self, item: FFItem) -> Tuple[APath, str]:
        """Return absolute path to item folder and item title."""
        path = self.tv_dir if item.ref.type == 'show' else self.movies_dir
        title = self.item_title(item)
        if item.year:
            return path / f'{title} ({item.year})', title
        return path / title, title

    def item_path(self, item: FFItem) -> APath:
        """Return absolute path to item folder."""
        path, _ = self.item_path_and_title(item)
        return path

    @contextmanager
    def write(self, path: APath) -> Iterator[KodiWritableFile]:
        """Just fill the file with its content"""
        if exists(path):
            yield DummyFile()
        else:
            with File(path, 'w') as file:
                yield file

    def mkdirs(self, path: APath) -> bool:
        """Create directories like APath.mkdir(parents=True, exist_ok=True)."""
        if exists(path):
            return True
        return mkdirs(path)

    def write_nfo(self, path: str, item: FFItem) -> None:
        """Write nfo info in base XML format
            TODO: Add more tags if neccessary
        """
        # root element
        media_tag = ET.Element(str(item.type))
        # child title elem
        title = ET.SubElement(media_tag, "title")
        title.text = item.title
        # child unique id elem
        uniqueid = ET.SubElement(media_tag, "uniqueid")
        uniqueid.set("type", "tmdb")
        uniqueid.set("default", "true")
        uniqueid.text = str(item.dbid)
        # create an ETree from root
        tree = ET.ElementTree(media_tag)
        ET.indent(tree, space="\t", level=0)
        # write to file
        tree.write(path, encoding="UTF-8", xml_declaration=True, method="xml")

    def _add_movie(self, item: FFItem, *, reload: bool = True) -> None:
        """Add single movie to the library."""
        ref = item.ref
        path, title = self.item_path_and_title(item)
        self.mkdirs(path)
        # prepare strm file
        with self.write(path / f'{title}.strm') as f:
            f.write(str(url_for(play_movie, dbid=ref.dbid)))
        # prepare nfo file
        with self.write(path / 'movie.nfo') as f:
            f.write(ffinfo.web_url(ref))
        # update kodi library
        if reload:
            executebuiltin("UpdateLibrary(video)", True)

    def _write_episode(self, ep: FFItem, *, path: APath, title: str) -> None:
        """Write single season."""
        with self.write(path / f'{title}.S{ep.season:02d}E{ep.episode:02d}.strm') as f:
            f.write(str(url_for(play_tvshow, tv_dbid=ep.ref.dbid, season=ep.ref.season, episode=ep.ref.episode)))

    def _write_season(self, sz: FFItem, *, path: APath, title: str, old_style: bool) -> None:
        """Write single season."""
        season_path = path if old_style else path / f'Season {sz.season}'
        self.mkdirs(season_path)
        # iterate over episodes
        for ep in sz.episode_iter():
            # prepare strm file
            self._write_episode(ep, path=season_path, title=title)

    def _add_show(self, item: FFItem, *, reload: bool = True) -> None:
        """Add single show (with all episodes) to the library."""
        show_item = item if item.ref.is_show else item.show_item
        if show_item is None:
            fflog(f'Missing show_item for {item.ref!r}')
            return
        path, title = self.item_path_and_title(show_item)
        self.mkdirs(path)
        if const.library.flat_show_folder:
            old_style = True
        else:
            # detect if any *.strm exists in the show folder
            old_style = bool(next(iter(path.glob('*.strm')), None))
        # write strm file(s)
        if item.ref.is_show:
            # iterate over seasons
            for sz in item.season_iter():
                self._write_season(sz, path=path, title=title, old_style=old_style)
        elif item.ref.is_season:
            # write single season
            self._write_season(item, path=path, title=title, old_style=old_style)
        elif item.ref.is_episode:
            # create season path and write single epsiode
            season_path = path if old_style else path / f'Season {item.season}'
            self.mkdirs(season_path)
            self._write_episode(item, path=season_path, title=title)
        else:
            fflog(f'PANIC!!! unknown ref {item.ref!r}')
        # prepare nfo file
        with self.write(path / 'tvshow.nfo') as f:
            f.write(ffinfo.web_url(show_item.ref))
        # update kodi library
        if reload:
            executebuiltin("UpdateLibrary(video)", True)

    def add_single(self, item: Union[MediaRef, FFItem], *, reload: bool = True) -> None:
        if isinstance(item, MediaRef):
            if found := ffinfo.find_item(item, progress=ffinfo.Progress.NO, tv_episodes=True, limit=0):
                item = found
            else:
                return
        if item.ref.is_movie:
            self._add_movie(item, reload=reload)
        elif item.ref.type == 'show':  # show, season, episode
            self._add_show(item, reload=reload)
        else:
            fflog(f'Unsupported type {item.ref!r}')

    def add_multiple(self, items) -> None:
        """Add multiple media items to library"""

        raise NotImplementedError('\nNOT implemented yet\n')

        heading = L(30124, 'Add to library')
        choices = Dialog().multiselect(heading, [item for item in items if item])
        if choices:
            for idx in choices:
                ffitem = items[idx]
                # make sure ffitem and dbid exist
                if ffitem:
                    dbid = ffitem.dbid
                    if dbid:
                        self.add_single(dbid, ffitem, reload=False)

            # update kodi library
            executebuiltin("UpdateLibrary(video)", True)


library = LibTools()


# class lib_tools:
#     @staticmethod
#     def create_folder(folder):
#         try:
#             folder = xbmcvfs.makeLegalFilename(folder)
#             control.make_dir(folder)

#             try:
#                 if "ftp://" not in folder:
#                     raise Exception()
#                 from ftplib import FTP

#                 ftparg = re.compile("ftp://(.+?):(.+?)@(.+?):?(\d+)?/(.+/?)").findall(
#                     folder
#                 )
#                 ftp = FTP(ftparg[0][2], ftparg[0][0], ftparg[0][1])
#                 try:
#                     ftp.cwd(ftparg[0][4])
#                 except:
#                     ftp.mkd(ftparg[0][4])
#                 ftp.quit()
#             except:
#                 pass
#         except:
#             pass

#     @staticmethod
#     def write_file(path, content):
#         try:
#             path = xbmcvfs.makeLegalFilename(path)
#             if not isinstance(content, basestring):
#                 content = str(content)

#             file = control.openFile(path, "w")
#             file.write(str(content))
#             file.close()
#         except Exception:
#             pass

#     @staticmethod
#     def nfo_url(media_string, ids):
#         tmdb_url = "https://www.themoviedb.org/%s/%s"
#         imdb_url = "http://www.imdb.com/title/%s/"

#         if "tmdb" in ids:
#             return tmdb_url % (media_string, str(ids["tmdb"]))
#         elif "imdb" in ids:
#             return imdb_url % (str(ids["imdb"]))
#         else:
#             return ""

#     @staticmethod
#     def check_sources(
#         title,
#         year,
#         imdb,
#         tmdb=None,
#         season=None,
#         episode=None,
#         tvshowtitle=None,
#         premiered=None,
#     ):
#         try:
#             from lib.ff import sources

#             src = sources.sources().getSources(
#                 title, title, year, imdb, tmdb, season, episode, tvshowtitle, premiered
#             )
#             return src and len(src) > 5
#         except:
#             return False

#     @staticmethod
#     def legal_filename(filename):
#         try:
#             filename = filename.strip()
#             filename = re.sub(r"(?!%s)[^\w\-_\.]", ".", filename)
#             filename = re.sub("\.+", ".", filename)
#             filename = re.sub(
#                 re.compile("(CON|PRN|AUX|NUL|COM\d|LPT\d)\.", re.I), "\\1_", filename
#             )
#             xbmcvfs.makeLegalFilename(filename)
#             return filename
#         except:
#             return filename

#     @staticmethod
#     def make_path(base_path, title, year="", season=""):
#         show_folder = re.sub(r"[^\w\-_\. ]", "_", title)
#         show_folder = "%s (%s)" % (show_folder, year) if year else show_folder
#         path = os.path.join(base_path, show_folder)
#         if season:
#             path = os.path.join(path, "Season %s" % season)
#         return path


# class libmovies:
#     def __init__(self):
#         self.library_folder = os.path.join(
#             control.transPath(control.settings.getString("library.movie")), ""
#         )

#         self.library_setting = control.settings.getBool("library.update")
#         self.dupe_setting = control.settings.getBool("library.check")
#         self.silentDialog = False
#         self.infoDialog = False

#     def add(self, name, title, localtitle, year, imdb, tmdb, range=False):
#         if (
#             not control.condVisibility("Window.IsVisible(infodialog)")
#             and not control.condVisibility("Player.HasVideo")
#             and self.silentDialog is False
#         ):
#             control.infoDialog(control.lang(32552).encode("utf-8"), time=10000000)
#             self.infoDialog = True

#         try:
#             if not self.dupe_setting:
#                 raise Exception()

#             id = [imdb, tmdb] if not tmdb == "0" else [imdb]
#             lib = control.jsonrpc(
#                 '{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["imdbnumber", "originaltitle", "year"]}, "id": 1}'
#                 % (year, str(int(year) + 1), str(int(year) - 1))
#             )
#             lib = json.loads(lib)["result"]["movies"]
#             lib = [
#                 i
#                 for i in lib
#                 if str(i["imdbnumber"]) in id
#                 or (i["originaltitle"] == title and str(i["year"]) == year)
#             ][0]
#         except:
#             lib = []

#         files_added = 0

#         try:
#             if not lib == []:
#                 raise Exception()

#             self.strmFile(
#                 {"name": name, "title": title, "localtitle": localtitle, "year": year, "imdb": imdb, "tmdb": tmdb}
#             )
#             files_added += 1
#         except:
#             pass

#         if range:
#             return

#         if self.infoDialog:
#             control.infoDialog(control.lang(32554), time=1)

#         if (
#             self.library_setting
#             and not control.condVisibility("Library.IsScanningVideo")
#             and files_added > 0
#         ):
#             control.execute("UpdateLibrary(video)")

#     def silent(self, url):
        

#         if not control.condVisibility(
#             "Window.IsVisible(infodialog)"
#         ) and not control.condVisibility("Player.HasVideo"):
#             control.infoDialog(control.lang(32552), time=10000000)
#             self.infoDialog = True
#             self.silentDialog = True

#         from lib.indexers import movies

#         items = movies.movies().get(url, idx=False)
#         if items is None:
#             items = []

#         for i in items:
#             try:
#                 if xbmc.Monitor().abortRequested():
#                     return sys.exit()
                    
#                 self.add(
#                     "%s (%s)" % (i["originaltitle"], i["year"]),
#                     i["originaltitle"],
#                     i["title"],
#                     i["year"],
#                     i["imdb"],
#                     i["tmdb"],
#                     range=True,
#                 )
#             except:
#                 pass

#         if self.infoDialog:
#             self.silentDialog = False
#             control.infoDialog(control.lang(32835), time=1)
            
#         if self.library_setting and not control.condVisibility(
#             "Library.IsScanningVideo"
#         ):
#             control.execute("UpdateLibrary(video)")

#     def range(self, url):
        

#         yes = control.yesnoDialog(control.lang(32555))
#         if not yes:
#             return

#         if not control.condVisibility(
#             "Window.IsVisible(infodialog)"
#         ) and not control.condVisibility("Player.HasVideo"):
#             control.infoDialog(control.lang(32552), time=10000000)
#             self.infoDialog = True

#         from lib.indexers import movies

#         items = movies.movies().get(url, idx=False, return_all=True, skip_superinfo=True)
#         if items is None:
#             items = []

#         for i in items:
#             try:
#                 if xbmc.Monitor().abortRequested():
#                     return sys.exit()
#                 self.add(
#                     "%s (%s)" % (i["originaltitle"], i["year"]),
#                     i["originaltitle"],
#                     i["title"],
#                     i["year"],
#                     i["imdb"],
#                     i["tmdb"],
#                     range=True,
#                 )
#             except:
#                 pass

#         if self.infoDialog:
#             control.infoDialog(control.lang(32554), time=1)

#         if self.library_setting and not control.condVisibility(
#             "Library.IsScanningVideo"
#         ):
#             control.execute("UpdateLibrary(video)")

#     def multi(self, select):
#         list = ast.literal_eval(cache.cache_get(select)["value"])
#         choice = [f'{i["title_multi"]} ({i["year"]})' for i in list]
#         select = control.dialog().multiselect("Wybierz tytuły", choice)
#         # items = [list[i] for i in select]
#         yes = control.yesnoDialog(control.lang(32555))
#         if not yes:
#             return

#         if not control.condVisibility(
#             "Window.IsVisible(infodialog)"
#         ) and not control.condVisibility("Player.HasVideo"):
#             control.infoDialog(control.lang(32552), time=10000000)
#             self.infoDialog = True

#         items = [list[i] for i in select] or None

#         if items is None:
#             items = []

#         for i in items:
#             try:
#                 if xbmc.Monitor().abortRequested():
#                     return sys.exit()
#                 self.add(
#                     "%s (%s)" % (i["title"], i["year"]),
#                     i["title"],
#                     i["title_multi"],
#                     i["year"],
#                     i["imdb"],
#                     i["tmdb"],
#                     range=True,
#                 )
#             except:
#                 pass

#         if self.infoDialog:
#             control.infoDialog(control.lang(32554), time=1)

#         if self.library_setting and not control.condVisibility(
#             "Library.IsScanningVideo"
#         ):
#             control.execute("UpdateLibrary(video)")

#     def strmFile(self, i):
#         try:
#             name, title, localtitle, year, imdb, tmdb = (
#                 i["name"],
#                 i["title"],
#                 i["localtitle"],
#                 i["year"],
#                 i["imdb"],
#                 i["tmdb"],
#             )

#             sysname = urllib.quote_plus(name)
#             systitle = urllib.quote_plus(title)
#             syslocaltitle = urllib.quote_plus(localtitle)
#             transtitle = cleantitle.normalize(
#                 title.translate({ord(c): "" for c in r'\/:*?"<>|'})
#             )

#             content = "%s?action=play&name=%s&title=%s&localtitle=%s&year=%s&imdb=%s&tmdb=%s" % (
#                 sys.argv[0],
#                 sysname,
#                 systitle,
#                 syslocaltitle,
#                 year,
#                 imdb,
#                 tmdb,
#             )

#             folder = lib_tools.make_path(self.library_folder, transtitle, year)

#             lib_tools.create_folder(folder)
#             lib_tools.write_file(
#                 os.path.join(folder, lib_tools.legal_filename(transtitle) + ".strm"),
#                 content,
#             )
#             lib_tools.write_file(
#                 os.path.join(folder, "movie.nfo"), lib_tools.nfo_url("movie", i)
#             )
#         except:
#             pass

# #PO ZMIANIE SUPER_INFO PAMIĘTAĆ O TYTUŁACH!
# class libtvshows:
#     def __init__(self):
#         self.library_folder = os.path.join(
#             control.transPath(control.settings.getString("library.tv")), ""
#         )

#         self.version = control.version()

#         self.include_unknown = control.settings.getBool("library.include_unknown")
#         self.library_setting = control.settings.getBool("library.update")
#         self.dupe_setting = control.settings.getBool("library.check")

#         self.datetime = datetime.datetime.utcnow() - datetime.timedelta(hours=1)
#         self.date = (self.datetime - datetime.timedelta(hours=6)).strftime("%Y%m%d")
#         self.silentDialog = False
#         self.infoDialog = False
#         self.block = False

#     def add(
#         self,
#         imdb,
#         tmdb,
#         season=None,
#         episode=None,
#         range=False,
#         title=None,
#         originaltitle=None,
#         year=None
#     ):
#         if (
#             not control.condVisibility("Window.IsVisible(infodialog)")
#             and not control.condVisibility("Player.HasVideo")
#             and self.silentDialog is False
#         ):
#             control.infoDialog(control.lang(32552), time=10000000)
#             self.infoDialog = True

#         from lib.indexers.episodes import Episodes
#         items = Episodes().get(
#             imdb, tmdb, season, episode, idx=False
#         )
#         try:
#             items = [
#                 {
#                     "title": i["title"] or title,
#                     "year": i["year"] or year,
#                     "imdb": i["imdb"],
#                     "tmdb": i["tmdb"],
#                     "season": i["season"],
#                     "episode": i["episode"],
#                     "tvshowtitle": i["originaltvshowtitle"] or originaltitle,
#                     "premiered": i["premiered"],
#                 }
#                 for i in items
#             ]
#         except:
#             items = []

#         try:
#             if not self.dupe_setting:
#                 raise Exception()
#             if not items:
#                 raise Exception()

#             id = [items[0]["imdb"], items[0]["tmdb"]]

#             lib = control.jsonrpc(
#                 '{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"properties" : ["imdbnumber", "title", "year"]}, "id": 1}'
#             )
#             lib = json.loads(lib)["result"]["tvshows"]
#             lib = [
#                 i["title"]
#                 for i in lib
#                 if str(i["imdbnumber"]) in id
#                 or (
#                     i["title"] == items[0]["tvshowtitle"]
#                     and str(i["year"]) == items[0]["year"]
#                 )
#             ][0]

#             lib = control.jsonrpc(
#                 '{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "tvshow", "operator": "is", "value": "%s"}]}, "properties": ["season", "episode"]}, "id": 1}'
#                 % lib
#             )
#             lib = json.loads(lib)["result"]["episodes"]
#             lib = ["S%02dE%02d" % (int(i["season"]), int(i["episode"])) for i in lib]

#             items = [
#                 i
#                 for i in items
#                 if "S%02dE%02d" % (int(i["season"]), int(i["episode"])) not in lib
#             ]
#         except:
#             pass

#         files_added = 0

#         for i in items:
#             try:
#                 if xbmc.Monitor().abortRequested():
#                     return sys.exit()

#                 premiered = i.get("premiered", "0")
#                 if (
#                     premiered != "0"
#                     and int(re.sub("[^0-9]", "", str(premiered))) > int(self.date)
#                 ) or (premiered == "0" and not self.include_unknown):
#                     continue

#                 self.strmFile(i)
#                 files_added += 1
#             except:
#                 pass

#         if range:
#             return

#         if self.infoDialog is True:
#             control.infoDialog(control.lang(32554), time=1)

#         if (
#             self.library_setting
#             and not control.condVisibility("Library.IsScanningVideo")
#             and files_added > 0
#         ):
#             control.execute("UpdateLibrary(video)")

#     def silent(self, url):
        

#         if not control.condVisibility(
#             "Window.IsVisible(infodialog)"
#         ) and not control.condVisibility("Player.HasVideo"):
#             control.infoDialog(control.lang(32608), time=10000000)
#             self.infoDialog = True
#             self.silentDialog = True

#         from lib.indexers import tvshows

#         items = tvshows.tvshows().get(url, idx=False)
#         if items is None:
#             items = []

#         for i in items:
#             try:

#                 if xbmc.Monitor().abortRequested():
#                     return sys.exit()
#                 self.add(i["imdb"], i["tmdb"], range=True)
#             except:
#                 pass

#         if self.infoDialog is True:
#             self.silentDialog = False
#             control.infoDialog(control.lang(32836), time=1)

#         if self.library_setting and not control.condVisibility(
#             "Library.IsScanningVideo"
#         ):
#             control.execute("UpdateLibrary(video)")


#     def range(self, url):
        
#         yes = control.yesnoDialog(control.lang(32555))
#         if not yes:
#             return

#         if not control.condVisibility(
#             "Window.IsVisible(infodialog)"
#         ) and not control.condVisibility("Player.HasVideo"):
#             control.infoDialog(control.lang(32552), time=10000000)
#             self.infoDialog = True

#         from lib.indexers import tvshows

#         items = tvshows.tvshows().get(url, idx=False, return_all=True, skip_superinfo=True)
#         if items is None:
#             items = []
#         for i in items:
#             try:
#                 if xbmc.Monitor().abortRequested():
#                     return sys.exit()
#                 self.add(i.get("imdb"), i.get("tmdb"), season=i.get("season"), episode=i.get("episode"), range=True,
#                          title=i.get('title'), originaltitle=i.get('originaltitle'), year=i.get('year'))
#             except:
#                 pass

#         if self.infoDialog:
#             control.infoDialog(control.lang(32554), time=1)

#         if self.library_setting and not control.condVisibility(
#             "Library.IsScanningVideo"
#         ):
#             control.execute("UpdateLibrary(video)")

#     def strmFile(self, i):
#         try:
#             title, year, imdb, tmdb, season, episode, tvshowtitle, premiered = (
#                 i["title"],
#                 i["year"],
#                 i["imdb"],
#                 i["tmdb"],
#                 i["season"],
#                 i["episode"],
#                 i["tvshowtitle"],
#                 i["premiered"],
#             )
#             episodetitle = urllib.quote_plus(title)
#             systitle, syspremiered = urllib.quote_plus(tvshowtitle), urllib.quote_plus(
#                 premiered
#             )

#             table = str.maketrans(dict.fromkeys('\/:*?"<>|'))
#             transtitle = tvshowtitle.translate(table)

#             content = (
#                 "%s?action=play&title=%s&year=%s&imdb=%s&tmdb=%s&season=%s&episode=%s&tvshowtitle=%s&date=%s"
#                 % (
#                     sys.argv[0],
#                     episodetitle,
#                     year,
#                     imdb,
#                     tmdb,
#                     season,
#                     episode,
#                     systitle,
#                     syspremiered,
#                 )
#             )

#             folder = lib_tools.make_path(self.library_folder, transtitle, year)
#             if not os.path.isfile(os.path.join(folder, "tvshow.nfo")):
#                 lib_tools.create_folder(folder)
#                 lib_tools.write_file(
#                     os.path.join(folder, "tvshow.nfo"), lib_tools.nfo_url("tv", i)
#                 )

#             folder = lib_tools.make_path(self.library_folder, transtitle, year, season)
#             lib_tools.create_folder(folder)
#             lib_tools.write_file(
#                 os.path.join(
#                     folder,
#                     lib_tools.legal_filename(
#                         "%s S%02dE%02d" % (transtitle, int(season), int(episode))
#                     )
#                     + ".strm",
#                 ),
#                 content,
#             )
#         except:
#             pass


# class libepisodes:
#     def __init__(self):
#         self.library_folder = os.path.join(
#             control.transPath(control.settings.getString("library.tv")), ""
#         )

#         self.library_setting = control.settings.getBool("library.update")
#         self.include_unknown = control.settings.getBool("library.include_unknown")
#         self.property = "%s_service_property" % control.addonInfo("name").lower()

#         self.datetime = datetime.datetime.utcnow() - datetime.timedelta(hours=1)
#         self.date = (self.datetime - datetime.timedelta(hours=6)).strftime("%Y%m%d")

#         self.infoDialog = False

#     def update(self, query=None, info=True):

#         try:

#             items = []
#             season, episode = [], []
#             show = [
#                 os.path.join(self.library_folder, i)
#                 for i in control.listDir(self.library_folder)[0]
#             ]
#             for s in show:
#                 try:
#                     season += [os.path.join(s, i) for i in control.listDir(s)[0]]
#                 except:
#                     pass
#             for s in season:
#                 try:
#                     episode.append(
#                         [
#                             os.path.join(s, i)
#                             for i in control.listDir(s)[1]
#                             if i.endswith(".strm")
#                         ][-1]
#                     )
#                 except:
#                     pass

#             for file in episode:
#                 try:
#                     file = control.openFile(file)
#                     read = file.read()
#                     file.close()

#                     if not read.startswith(sys.argv[0]):
#                         raise Exception()

#                     params = dict(urllib.parse_qsl(read.replace("?", "")))

#                     try:
#                         tvshowtitle = params["tvshowtitle"]
#                     except:
#                         tvshowtitle = None
#                     try:
#                         tvshowtitle = params["show"]
#                     except:
#                         pass
#                     if tvshowtitle is None or tvshowtitle == "":
#                         raise Exception()

#                     year, imdb, tmdb = params["year"], params["imdb"], params["tmdb"]

#                     imdb = "tt" + re.sub("[^0-9]", "", str(imdb))

#                     try:
#                         tmdb = params["tmdb"]
#                     except:
#                         tmdb = "0"

#                     items.append(
#                         {
#                             "tvshowtitle": tvshowtitle,
#                             "year": year,
#                             "imdb": imdb,
#                             "tmdb": tmdb,
#                         }
#                     )
#                 except:
#                     pass

#             items = [i for x, i in enumerate(items) if i not in items[x + 1 :]]
#             if len(items) == 0:
#                 raise Exception()
#         except:
#             return

#         try:
#             lib = control.jsonrpc(
#                 '{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"properties" : ["imdbnumber", "title", "year"]}, "id": 1}'
#             )
#             lib = json.loads(lib)["result"]["tvshows"]
#         except:
#             return

#         if (
#             info
#             and not control.condVisibility("Window.IsVisible(infodialog)")
#             and not control.condVisibility("Player.HasVideo")
#         ):
#             control.infoDialog(control.lang(32553), time=10000000)
#             self.infoDialog = True

#         try:
#             control.make_dir(control.dataPath)
#             dbcon = database.connect(control.libcacheFile)
#             dbcur = dbcon.cursor()
#             dbcur.execute(
#                 "CREATE TABLE IF NOT EXISTS tvshows ("
#                 "id TEXT, "
#                 "items TEXT, "
#                 "UNIQUE(id)"
#                 ");"
#             )
#         except:
#             return

#         try:
#             from lib.indexers.episodes import Episodes
#         except:
#             return

#         files_added = 0

#         # __init__ doesn't get called from services so self.date never gets updated and new episodes are not added to the library
#         self.datetime = datetime.datetime.utcnow() - datetime.timedelta(hours=1)
#         self.date = (self.datetime - datetime.timedelta(hours=6)).strftime("%Y%m%d")

#         for item in items:
#             it = None

#             if xbmc.Monitor().abortRequested():
#                 return sys.exit()

#             try:
#                 dbcur.execute("SELECT * FROM tvshows WHERE id = '%s'" % item["tmdb"])
#                 fetch = dbcur.fetchone()
#                 it = eval(fetch[1])
#             except:
#                 pass

#             try:
#                 if it is not None:
#                     raise Exception()

#                 it = Episodes().get(
#                     item["imdb"],
#                     item["tmdb"],
#                     idx=False,
#                 )

#                 status = it[0]["status"].lower()

#                 it = [
#                     {
#                         "title": i["title"],
#                         "year": i["year"],
#                         "imdb": i["imdb"],
#                         "tmdb": i["tmdb"],
#                         "season": i["season"],
#                         "episode": i["episode"],
#                         "tvshowtitle": i["tvshowtitle"],
#                         "premiered": i["premiered"],
#                     }
#                     for i in it
#                 ]

#                 if status == "continuing":
#                     raise Exception()
#                 dbcur.execute(
#                     "INSERT INTO tvshows Values (?, ?)", (item["tmdb"], repr(it))
#                 )
#                 dbcon.commit()
#             except:
#                 pass

#             try:
#                 id = [item["imdb"], item["tmdb"]]
#                 if not item["tmdb"] == "0":
#                     id += [item["tmdb"]]

#                 ep = [
#                     x["title"]
#                     for x in lib
#                     if str(x["imdbnumber"]) in id
#                     or (
#                         x["title"] == item["tvshowtitle"]
#                         and str(x["year"]) == item["year"]
#                     )
#                 ][0]
#                 ep = control.jsonrpc(
#                     '{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "tvshow", "operator": "is", "value": "%s"}]}, "properties": ["season", "episode"]}, "id": 1}'
#                     % ep
#                 )
#                 ep = json.loads(ep).get("result", {}).get("episodes", {})
#                 ep = [
#                     {"season": int(i["season"]), "episode": int(i["episode"])}
#                     for i in ep
#                 ]
#                 ep = sorted(ep, key=lambda x: (x["season"], x["episode"]))[-1]

#                 num = [
#                     x
#                     for x, y in enumerate(it)
#                     if str(y["season"]) == str(ep["season"])
#                     and str(y["episode"]) == str(ep["episode"])
#                 ][-1]
#                 it = [y for x, y in enumerate(it) if x > num]
#                 if len(it) == 0:
#                     continue
#             except:
#                 continue

#             for i in it:
#                 try:
#                     if xbmc.Monitor().abortRequested():
#                         return sys.exit()

#                     premiered = i.get("premiered", "0")
#                     if (
#                         premiered != "0"
#                         and int(re.sub("[^0-9]", "", str(premiered))) > int(self.date)
#                     ) or (premiered == "0" and not self.include_unknown):
#                         continue

#                     libtvshows().strmFile(i)
#                     files_added += 1
#                 except:
#                     pass

#         if self.infoDialog:
#             control.infoDialog(control.lang(32554), time=1)

#         if (
#             self.library_setting
#             and not control.condVisibility("Library.IsScanningVideo")
#             and files_added > 0
#         ):
#             control.execute("UpdateLibrary(video)")

#     def service(self):
#         try:
#             lib_tools.create_folder(
#                 os.path.join(control.transPath(control.settings.getString("library.movie")), "")
#             )
#             lib_tools.create_folder(
#                 os.path.join(control.transPath(control.settings.getString("library.tv")), "")
#             )
#         except:
#             pass

#         try:
#             control.make_dir(control.dataPath)
#             dbcon = database.connect(control.libcacheFile)
#             dbcur = dbcon.cursor()
#             dbcur.execute(
#                 "CREATE TABLE IF NOT EXISTS service ("
#                 "setting TEXT, "
#                 "value TEXT, "
#                 "UNIQUE(setting)"
#                 ");"
#             )
#             dbcur.execute("SELECT * FROM service WHERE setting = 'last_run'")
#             fetch = dbcur.fetchone()
#             if fetch is None:
#                 serviceProperty = "1970-01-01 23:59:00.000000"
#                 dbcur.execute(
#                     "INSERT INTO service Values (?, ?)", ("last_run", serviceProperty)
#                 )
#                 dbcon.commit()
#             else:
#                 serviceProperty = str(fetch[1])
#             dbcon.close()
#         except:
#             try:
#                 return dbcon.close()
#             except:
#                 return

#         try:
#             control.window().setProperty(self.property, serviceProperty)
#         except:
#             return

#         while not xbmc.Monitor().abortRequested():
#             try:
#                 serviceProperty = control.window().getProperty(self.property)

#                 t1 = datetime.timedelta(hours=6)
#                 t2 = datetime.datetime.strptime(serviceProperty, "%Y-%m-%d %H:%M:%S.%f")
#                 t3 = datetime.datetime.now()

#                 check = abs(t3 - t2) > t1
#                 if not check:
#                     raise Exception()

#                 if control.player().isPlaying() or control.condVisibility(
#                     "Library.IsScanningVideo"
#                 ):
#                     raise Exception()

#                 serviceProperty = datetime.datetime.now().strftime(
#                     "%Y-%m-%d %H:%M:%S.%f"
#                 )

#                 control.window().setProperty(self.property, serviceProperty)

#                 try:
#                     dbcon = database.connect(control.libcacheFile)
#                     dbcur = dbcon.cursor()
#                     dbcur.execute(
#                         "CREATE TABLE IF NOT EXISTS service ("
#                         "setting TEXT, "
#                         "value TEXT, "
#                         "UNIQUE(setting)"
#                         ");"
#                     )
#                     dbcur.execute("DELETE FROM service WHERE setting = 'last_run'")
#                     dbcur.execute(
#                         "INSERT INTO service Values (?, ?)",
#                         ("last_run", serviceProperty),
#                     )
#                     dbcon.commit()
#                     dbcon.close()
#                 except:
#                     try:
#                         dbcon.close()
#                     except:
#                         pass

#                 if not control.settings.getBool("library.service.update"):
#                     raise Exception()
#                 info = control.settings.getBool("library.service.notification")
#                 self.update(info=info)
#             except:
#                 pass

#             control.sleep(10000)


if __name__ == '__main__':
    from .cmdline import DebugArgumentParser, parse_ref
    from const import constdef
    from ..service.client import service_client

    p = DebugArgumentParser(dest='cmd')
    p.add_argument('--media-dir', help='override media folder')
    p.add_argument('--service', action='store_true', help='start service')
    p.add_argument('--no-service', action='store_false', dest='service', help='skip service (default)')
    with p.with_subparser('add') as pp:
        pp.add_argument('ref', type=parse_ref, help='ref to media')
    args = p.parse_args()

    if args.service:
        pass
        # service = start_service()
    else:
        constdef.locked = False  # type: ignore
        const.tune.service.http_server.try_count = 1
        constdef.locked = True  # type: ignore
        service = None
        service_client.__class__.LOG_EXCEPTION = False
    if args.media_dir:
        LibTools._DEBUG_FOLDER = args.media_dir
    if args.cmd == 'add':
        library.add_single(args.ref, reload=False)

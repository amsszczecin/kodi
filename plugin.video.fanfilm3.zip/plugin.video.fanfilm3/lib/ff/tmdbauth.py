# -*- coding: utf-8 -*-


import requests

from lib.ff import apis, control, log_utils


class Auth:
    def __init__(self):
        self.auth_base_link = "https://api.themoviedb.org/3/authentication"
        self.tm_user = control.settings.getString("tmdb.api_key") or apis.tmdb_API

    def create_session_id(self):
        try:
            if control.settings.getString("tmdb.username") == "" or control.settings.getString("tmdb.password") == "":
                return control.dialog().notification("Błąd", "Wypełnij pola logowania", "ERROR")
            url = self.auth_base_link + "/token/new?api_key=%s" % self.tm_user
            result = requests.get(url).json()
            token = result.get("request_token")
            url2 = self.auth_base_link + "/token/validate_with_login?api_key=%s" % self.tm_user
            username = control.settings.getString("tmdb.username")
            password = control.settings.getString("tmdb.password")
            post2 = {"username": "%s" % username, "password": "%s" % password, "request_token": "%s" % token}
            requests.post(url2, data=post2).json()
            url3 = self.auth_base_link + "/session/new?api_key=%s" % self.tm_user
            post3 = {"request_token": "%s" % token}
            result3 = requests.post(url3, data=post3).json()
            if result3.get("success") is True:
                session_id = result3.get("session_id")
                msg = "%s" % (
                    "login =" + username + "[CR]hasło =" + password + "[CR]token = " + token + "[CR]Potwierdzasz?"
                )
                if control.yesnoDialog(msg):
                    control.settings.setString("tmdb.sessionid", session_id)
                    control.infoDialog("FanFilm autoryzacja TMDB", "Autoryzacja udana", "default")
                else:
                    control.infoDialog("Autoryzacja TMDB nie powiodła się", "Wystąpił błąd", "ERROR")
            else:
                control.infoDialog("Autoryzacja TMDB nie powiodła się", "Wystąpił błąd", "ERROR")
        except Exception:
            control.infoDialog("Autoryzacja TMDB nie powiodła się", "Wystąpił błąd", "ERROR")
            log_utils.fflog_exc()

    def revoke_session_id(self):
        try:
            if control.settings.getString("tmdb.sessionid") == "":
                return
            url = self.auth_base_link + "/session?api_key=%s" % self.tm_user
            post = {"session_id": "%s" % control.settings.getString("tmdb.sessionid")}
            result = requests.delete(url, data=post).json()
            if result.get("success") is True:
                control.settings.setString("tmdb.sessionid", "")
                control.infoDialog("FanFilm autoryzacja TMDB", "Usunięto dane", "default")
            else:
                control.infoDialog("Deautoryzacja TMDB nie powiodła się", "Wystąpił błąd", "ERROR")
        except:
            control.infoDialog("Deautoryzacja TMDB nie powiodła się", "Wystąpił błąd", "ERROR")
            log_utils.fflog_exc()

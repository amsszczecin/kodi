"""Common types."""

from sys import version_info
from typing import Optional, Union, Any, List, Dict, TypeVar, Type, TYPE_CHECKING
from collections.abc import Sized, Collection, Sequence, Reversible
from typing_extensions import Protocol, Generic, Self, get_origin, get_args, runtime_checkable
if version_info >= (3, 10):
    from types import UnionType
else:
    UnionType = Union
if TYPE_CHECKING:
    from datetime import tzinfo, date as dt_date, time as dt_time


#: Any JSON data object.
JsonData = Dict[str, Any]
#: Any JSON data.
JsonResult = Union[JsonData, List[JsonData]]

#: Keyword arguements.
KwArgs = Dict[str, Any]

#: Any patameters.
Params = Dict[str, Any]


T = TypeVar('T')


if version_info >= (3, 10):

    def is_union(ann: Type[T]) -> bool:
        """Return True if type is Union."""
        origin = get_origin(ann)
        return origin is Union or origin is UnionType

else:

    def is_union(ann: Type[T]) -> bool:
        """Return True if type is Union."""
        return get_origin(ann) is Union


def is_optional(ann: Type[T]) -> bool:
    """Return True if `ann` is optional. Optional[X] is equivalent to Union[X, None]."""
    args = get_args(ann)
    return is_union(ann) and len(args) == 2 and args[1] is type(None)


def remove_optional(ann: Type[T]) -> Type[T]:
    """Remove Optional[X] (if exists) and returns X."""
    args = get_args(ann)
    if is_union(ann) and len(args) == 2 and args[1] is type(None):
        return args[0]
    return ann


def is_union_none(ann: Type[T]) -> bool:
    """Return True if `ann` could be None. Union[None, ...] or Optional[X]."""
    args = get_args(ann)
    return get_origin(ann) is Union and any(a is type(None) or a is None for a in args)


@runtime_checkable
class DateTime(Protocol):
    """Simplifed py datetime class."""

    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int
    microsecond: int

    @classmethod
    def today(cls) -> Self: ...

    @classmethod
    def now(cls) -> Self: ...

    @classmethod
    def utcnow(cls) -> Self: ...

    @classmethod
    def fromtimestamp(cls, timestamp: float, tz: Optional['tzinfo'] = None) -> Self: ...

    @classmethod
    def combine(cls, date: 'dt_date', time: 'dt_time', tzinfo: Optional['tzinfo'] = None) -> Self: ...

    def isoformat(self) -> str: ...

    def date(self) -> 'dt_date': ...

    def time(self) -> 'dt_time': ...


class PagedItemList(Reversible, Collection, Protocol):  # Generic[T]):
    """Item list with pagination info."""

    @property
    def page(self) -> int: ...

    @property
    def total_pages(self) -> int: ...

    def next_page(self) -> Optional[int]: ...

"""Tiny TheMovieDB.org API getter."""

from typing import Optional

from ..api.tmdb import TmdbApi, TmdbCredentials
from ..ff import apis
from .settings import settings
from const import const


class Tmdb(TmdbApi):
    """API for themoviedb.org."""

    def __init__(self):
        api_key: str = const.dev.tmdb.api_key or apis.tmdb_API
        super().__init__(api_key=api_key)

    def credentials(self) -> TmdbCredentials:
        """Return current credencials."""
        if self.api_key is not None:
            user: str = settings.getString('tmdb.username')
            password: str = settings.getString('tmdb.password')
            session_id: str = settings.getString('tmdb.sessionid')
            return TmdbCredentials(api_key=self.api_key, user=user, password=password,
                                   session_id=session_id)
        raise ValueError('Missing TMDB api_key')

    def set_session_id(self, session_id: Optional[str]) -> None:
        """Set session ID. Save session ID or remove if None."""
        settings.setString('tmdb.sessionid', session_id or '')


#: Global Trakt.tv support.
tmdb = Tmdb()

# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from datetime import datetime
import json
import time

from . import control
from .db_connection_manager import connection_manager
from .log_utils import fflog, fflog_exc


def get_db_connection():
    # Korzystamy z connection_manager, aby uzyskać połączenie
    return connection_manager.get_connection("metacache", control.metacacheFile)

def create_meta_table_if_not_exists():
    try:
        dbcon = get_db_connection()
        dbcur = dbcon.cursor()

        # Utwórz tabelę meta jeśli nie istnieje
        dbcur.execute(
            "CREATE TABLE IF NOT EXISTS meta ("
            "next TEXT, imdb TEXT, tmdb TEXT, tvshow_imdb TEXT, tvshow_tmdb TEXT, title TEXT, originaltitle TEXT, originalname TEXT, label TEXT, plot TEXT, tagline TEXT, "
            "premiered TEXT, year TEXT, mpaa TEXT, status TEXT, studio TEXT, genre TEXT, country TEXT, duration TEXT, "
            "rating REAL, votes INTEGER, castwiththumb TEXT, director TEXT, writer TEXT, poster TEXT, landscape TEXT, "
            "fanart TEXT, banner TEXT, clearlogo TEXT, clearart TEXT, discart TEXT, providers TEXT, seasons INTEGER, season INTEGER, episode INTEGER, "
            "tvshowtitle TEXT, unaired TEXT, thumb TEXT, playcount INTEGER, "
            "insertion_date TEXT, UNIQUE(imdb, tmdb, season, episode));"
        )

    except Exception as e:
        fflog_exc(e)

def fetch(items, lang="en", user="", service=False):
    single_item = False
    if not isinstance(items, list):
        items = [items]
        single_item = True

    try:
        int(time.time())
        create_meta_table_if_not_exists()
        dbcon = get_db_connection()
        dbcur = dbcon.cursor()
    except:
        return items[0] if single_item else items

    for i in range(0, len(items)):
        break  # XXX
        try:
            imdb = items[i].get("imdb")
            tmdb = items[i].get("tmdb")
            season = items[i].get("season")
            episode = items[i].get("episode")

            # Default query for movies and shows without season or episode
            if not season and not episode:
                query = "SELECT * FROM meta WHERE (imdb = ? OR tmdb = ?) AND (season IS NULL OR season = '') AND (episode IS NULL OR episode = '')"
                args = (imdb, tmdb)
            # If season exists, then modify the query for seasons
            elif season and not episode:
                query = "SELECT * FROM meta WHERE (imdb = ? OR tmdb = ?) AND season = ? AND (episode IS NULL OR episode = '')"
                args = (imdb, tmdb, season)
            # If both season and episode exists, then modify the query for episodes
            elif season and episode:
                query = "SELECT * FROM meta WHERE (imdb = ? OR tmdb = ?) AND (season = ? AND episode = ?)"
                args = (imdb, tmdb, season, episode)

            dbcur.execute(query, args)
            match = dbcur.fetchone()

            if not match and season and episode:
                query = "SELECT * FROM meta WHERE (tvshow_tmdb = ? OR tvshow_tmdb = ?) AND (season = ? AND episode = ?)"
                args = (imdb, tmdb, season, episode)
                dbcur.execute(query, args)
                match = dbcur.fetchone()

            # services.py episode
            if not match and service:
                query = "SELECT * FROM meta WHERE (imdb = ? OR tmdb = ?)"
                args = (imdb, tmdb)
                dbcur.execute(query, args)
                match = dbcur.fetchone()

            if match is not None:
                columns = [column[0] for column in dbcur.description]
                item = dict(zip(columns, match))
                # Decode bytes to string
                for key, value in item.items():
                    if isinstance(value, bytes):
                        item[key] = value.decode("utf-8")
            else:
                continue

            items[i].update(item)
            items[i].update({"metacache": True})
        except Exception:
            fflog_exc()

    return items[0] if single_item else items


def update_watched_status(imdb=None, tmdb=None, season=None, episode=None, watched: bool = False):
    try:
        control.make_dir(control.dataPath)
        create_meta_table_if_not_exists()
        dbcon = get_db_connection()
        dbcur = dbcon.cursor()

        # Update query and parameters based on provided keys
        watched = int(bool(watched))
        if season is None and episode is None:
            update_query = "UPDATE meta SET playcount = ? WHERE (imdb = ? OR tmdb = ?)"
            update_params = (watched, imdb, tmdb)
        elif episode is None:
            update_query = "UPDATE meta SET playcount = ? WHERE (imdb = ? OR tmdb = ?) AND season = ?"
            update_params = (watched, imdb, tmdb, season)
        else:
            update_query = "UPDATE meta SET playcount = ? WHERE (imdb = ? OR tmdb = ?) AND (season = ? AND episode = ?)"
            update_params = (watched, imdb, tmdb, season, episode)

        dbcur.execute(update_query, update_params)

        dbcon.commit()
    except Exception:
        fflog_exc()


def insert(metas):
    if metas is None:
        fflog(f'insert({metas=}) – ignoring')

    if not isinstance(metas, (list, tuple)):
        metas = [metas]

    try:
        control.make_dir(control.dataPath)
        create_meta_table_if_not_exists()
        dbcon = get_db_connection()
        dbcur = dbcon.cursor()

        for meta in metas:
            # Check if the entry already exists
            if meta.get("episode") is None:
                select_query = (
                    "SELECT 1 FROM meta WHERE (imdb = ? OR tmdb = ?) AND season = ?"
                )
                select_params = (meta.get("imdb"), meta.get("tmdb"), meta.get("season"))
            else:
                select_query = "SELECT 1 FROM meta WHERE (imdb = ? OR tmdb = ?) AND (season = ? AND episode = ?)"
                select_params = (
                    meta.get("imdb"),
                    meta.get("tmdb"),
                    meta.get("season"),
                    meta.get("episode"),
                )

            dbcur.execute(select_query, select_params)
            if dbcur.fetchone():
                continue  # If an entry already exists, skip to the next iteration

            # Convert to JSON if castwiththumb and providers are dict or list
            castwiththumb = meta.get("castwiththumb")
            if isinstance(castwiththumb, (dict, list)):
                castwiththumb = json.dumps(castwiththumb)

            providers = meta.get("providers")
            if isinstance(providers, (dict, list)):
                providers = json.dumps(providers)

            insertion_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")

            dbcur.execute(
                "INSERT INTO meta Values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    meta.get("next"),
                    meta.get("imdb"),
                    meta.get("tmdb"),
                    meta.get("tvshow_imdb"),
                    meta.get("tvshow_tmdb"),
                    meta.get("title"),
                    meta.get("originaltitle"),
                    meta.get("originalname"),
                    meta.get("label"),
                    meta.get("plot"),
                    meta.get("tagline"),
                    meta.get("premiered"),
                    meta.get("year"),
                    meta.get("mpaa"),
                    meta.get("status"),
                    meta.get("studio"),
                    meta.get("genre"),
                    meta.get("country"),
                    meta.get("duration"),
                    meta.get("rating"),
                    meta.get("votes"),
                    castwiththumb,
                    meta.get("director"),
                    meta.get("writer"),
                    meta.get("poster"),
                    meta.get("landscape"),
                    meta.get("fanart"),
                    meta.get("banner"),
                    meta.get("clearlogo"),
                    meta.get("clearart"),
                    meta.get("discart"),
                    providers,
                    meta.get("seasons"),
                    meta.get("season"),
                    meta.get("episode"),
                    meta.get("tvshowtitle"),
                    meta.get("unaired"),
                    meta.get("thumb"),
                    meta.get("playcount", 0),
                    insertion_date,
                ),
            )

        dbcon.commit()
    except Exception:
        fflog_exc()


def remove_old_entries(days: int, preserve_playcount_1: bool = False):
    try:
        control.make_dir(control.dataPath)
        create_meta_table_if_not_exists()
        dbcon = get_db_connection()
        dbcur = dbcon.cursor()

        hours = float(days * 24)
        if hours == 0:
            return

        # Sprawdzamy, czy tabela istnieje.
        dbcur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='meta'"
        )
        if dbcur.fetchone() is None:
            # Jeśli tabela nie istnieje, kończymy wykonywanie funkcji.
            return

        now = datetime.now()

        dbcur.execute("SELECT * FROM meta")
        col_names = [desc[0] for desc in dbcur.description]  # Pobierz nazwy kolumn

        rows = dbcur.fetchall()
        for row in rows:
            row_dict = dict(
                zip(col_names, row)
            )  # Stwórz słownik z nazw kolumn i wartościami
            insertion_date = datetime.strptime(
                row_dict["insertion_date"], "%Y-%m-%d %H:%M:%S.%f"
            )
            difference = now - insertion_date

            if (
                difference.total_seconds() > hours * 3600
            ):  # Konwersja godzin na sekundy.
                # Jeśli opcja preserve_playcount_1 jest włączona, dodajemy warunek, aby nie usuwać wpisów z playcount równym 1.
                if preserve_playcount_1:
                    dbcur.execute(
                        "DELETE FROM meta WHERE (imdb = ? or tmdb = ?) AND (watched IS NULL OR watched != 1)",
                        (row_dict["imdb"], row_dict["tmdb"]),
                    )
                else:
                    dbcur.execute(
                        "DELETE FROM meta WHERE (imdb = ? or tmdb = ?)",
                        (row_dict["imdb"], row_dict["tmdb"]),
                    )

        dbcon.commit()
    except Exception:
        fflog_exc()

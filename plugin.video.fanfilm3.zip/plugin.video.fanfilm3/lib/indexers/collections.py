
from typing import List

from .core import Indexer
from .search import Search
from ..ff.routing import route, subobject, RouteObject, url_for, PathArg
from ..ff.item import FFItem
from ..ff.menu import KodiDirectory, directory, ContextMenuItem
from ..ff.tmdb import tmdb
from ..kolang import L


class Collections(RouteObject, Indexer):
    """Collections navigation (a little bit degraded)."""

    MODULE = 'collections'
    # TYPE = 'collection'
    VIEW = 'sets'

    @subobject
    def search(self) -> 'Search':
        """Search submodule."""
        return Search(indexer=self, type='collection')

    def do_show_item(self, kdir: KodiDirectory, it: FFItem, *, alone: bool, link: bool, menu: List[ContextMenuItem]) -> None:
        """Process stump search item. Called from search_items()."""
        # kdir.folder(name, url_for(self.item, oid=oid))
        it.mode = it.Mode.Folder
        it.url = str(url_for(self.item, oid=it.dbid))
        kdir.add(it, menu=menu)

    @route('/')
    def item(self, oid: PathArg[int]) -> None:
        from .navigator import nav
        items = tmdb.collection_items(oid)
        nav.show_items(items)

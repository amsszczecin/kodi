"""
    Fanfilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from datetime import date as dt_date, timedelta
from typing import Optional, List, TYPE_CHECKING
from typing_extensions import Literal

from ..ff.routing import route, subobject, RouteObject, url_for, PathArg
from ..ff.menu import directory, KodiDirectory, ContextMenuItem, CMenu
from ..ff.settings import settings
from ..ff.tmdb import tmdb
from ..ff.trakt2 import trakt
from ..api.tmdb import DiscoveryFilters
from ..api.tv import TvProgram, TvServiceName
from ..kolang import L
from ..main import play_movie
from ..ff.item import FFItem
from ..ff.db import state
from ..ff.log_utils import fflog
from .search import Search
from .core import MainIndexer
from const import const
if TYPE_CHECKING:
    from ..ff.routing import URL
    from ..api.tv import TvMovie


class Movies(RouteObject, MainIndexer):
    """Movies navigation."""

    MODULE = 'movies'
    TYPE = 'movie'
    VIDEO_TYPE = 'movie'
    TMBD_CONTENT = 'movie'
    TRAKT_CONTENT = 'movies'
    VOTE_COUNT_SETTING = 'tmdbmovie.vote'
    VIEW = 'movies'
    IMAGE = 'DefaultMovies.png'

    @route('/')
    def home(self) -> None:
        """Create root / main menu."""
        with directory(view='addons', icon='DefaultMovies.png') as kdir:
            if const.indexer.movies.joke.production_company:
                kdir.folder(L(30138, 'Companies'), url_for(self.joke, type='production_company'))
            if const.indexer.movies.joke.keyword:
                kdir.folder(L(30137, 'Keywords'), url_for(self.joke, type='keyword'))
            kdir.folder(L(32010, 'Search'), self.search, thumb='search.png')
            if trakt.credentials() or tmdb.credentials():
                kdir.folder(L(32003, 'My Movies'), self.lists, thumb='mymovies.png', icon='DefaultVideoPlaylists.png')
            if trakt.credentials():
                kdir.folder(L(32801, 'Currently watching'), self.resume, thumb='mymovies.png', icon='DefaultVideoPlaylists.png')
            kdir.folder(L(32017, 'People Watching'), self.trending, thumb='people-watching.png', icon='DefaultRecentlyAddedMovies.png')
            kdir.folder(L(32018, 'Most Popular'), self.popular, thumb='most-popular.png')
            kdir.folder(L(32019, 'Top rated'), self.top_rated, thumb='most-voted.png')
            kdir.folder(L(32011, 'Genres'), self.genre, thumb='genres.png')
            kdir.folder(L(32005, 'New Movies'), self.new, thumb='latest-movies.png', icon='DefaultRecentlyAddedMovies.png')
            kdir.folder(L(32022, 'In Theaters'), self.cinema, thumb='in-theaters.png', icon='DefaultRecentlyAddedMovies.png')
            kdir.folder(L(32007, 'Today in TV'), self.tv, thumb='calendar.png')
            kdir.folder(L(32020, 'Box Office'), self.boxoffice, thumb='box-office.png')
            kdir.folder(L(32012, 'Year'), self.year, icon='years.png')
            kdir.folder(L(32014, 'Languages'), self.language, thumb='languages.png')
            kdir.folder(L(30104, 'Countries'), self.country, thumb='country.png')
            kdir.folder(L(32631, 'Awards'), self.awards, thumb='awards.png')

    @subobject
    def search(self) -> 'Search':
        """Search submodule."""
        return Search(indexer=self)

    def not_so_today(self) -> dt_date:
        """Fake today, without cinema last N months."""
        today = self.today()
        months: int = settings.getInt('hidecinema.rollback') if settings.getBool('hidecinema') else 0
        if months:
            return today - timedelta(days=30 * months)
        return today

    def play_url(self, it: FFItem) -> Optional['URL']:
        """Returns URL for movie play."""
        if it.aired_before(self.today()) and not const.indexer.movies.future_playable:
            return url_for(KodiDirectory.no_op)
        return url_for(play_movie, dbid=it.dbid)

    def do_show_item(self, kdir: KodiDirectory, it: FFItem, *, alone: bool, link: bool, menu: List[ContextMenuItem]) -> None:
        """Process discover item. Called from discover()."""
        it.label = f'{it.title}'
        it.setLabel2('%T|%Y')
        it.mode = it.Mode.Playable
        self.item_progress(it, menu=menu)
        library_enabled = settings.getBool('enable_library')
        kdir.add(it, url=self.play_url(it), menu=[
            (L(30162, 'Details'), url_for(self.media_info, ref=it.ref)),
            CMenu(L(30124, 'Add to library'), url_for(self.add_to_library, ref=it.ref), visible=library_enabled),
            CMenu(L(30163, 'Add to library multiple'), url_for(self.add_to_library_multiple), visible=library_enabled)
        ])

    def post_show_items(self, kdir: KodiDirectory):
        """Called after item list folder is created."""
        refs = [item.ref for item in kdir.items if item.ref]
        state.set('multilib_refs', refs, module='library')

    def show_media_info_item(self, kdir: KodiDirectory, it: FFItem):
        """Add media item in details view."""
        it.mode = it.Mode.Separator
        it.label = f'[B]{it.title}[/B]'
        kdir.add(it, url=self.play_url(it))

    def discover_year(self, year: int, end: int, *, page: int = 1) -> None:
        """Discover media in year range. Override it for tune."""
        vote_count = const.indexer.movies.year.votes
        if year == end:
            return self.discover(page=page, votes=vote_count,
                                 sort_by='primary_release_date.asc', primary_release_year=year)
        else:
            return self.discover(page=page, votes=vote_count, sort_by='popularity.desc',
                                 primary_release_date=tmdb.Date.range(dt_date(year, 1, 1), dt_date(end, 12, 31)))

    @route
    def lists(self) -> None:
        """My movie lists."""
        from .navigator import nav
        with directory(view='sets', icon='DefaultMovies.png') as kdir:
            if trakt.credentials():
                kdir.folder(L(32032, 'Collection'), url_for(nav.trakt.collection, media_type='movie'), thumb='trakt.png')
                kdir.folder(L(32033, 'Watchlist'), url_for(nav.trakt.ulist, media_type='movie', list_type='watchlist', sort='added,asc'), thumb='trakt.png')
                kdir.folder(L(32035, 'Featured'), url_for(nav.trakt.recommendation, media_type='movie'), thumb='trakt.png')
                kdir.folder(L(32036, 'History'), url_for(nav.trakt.ulist, media_type='movie', list_type='history'), thumb='trakt.png')

            if tmdb.credentials():
                kdir.folder(L(32802, 'Watchlist TMDB'), url_for(nav.tmdb.watchlist, media_type='movie'), thumb='tmdb.png')
                kdir.folder(L(32803, 'Favourites TMDB'), url_for(nav.tmdb.favorite, media_type='movie'), thumb='tmdb.png')

            # if imdb.credentials():
            #     ... L(32804, 'Watchlist IMDb')

            if trakt.credentials():
                kdir.folder(L(30164, 'My Trakt Lists'), url_for(nav.trakt.mine, media_type='movie'), thumb='userlists.png')
            if tmdb.credentials():
                kdir.folder(L(30165, 'My TMDB Lists'), url_for(nav.tmdb.mine, media_type='movie'), thumb='userlists.png')
            # if imdb.credentials():
            #     kdir.folder(L('My IMDB Lists'), url_for(nav.imdb.mine), thumb='userlists.png')

    @route
    def popular(self, *, page: PathArg[int] = 1) -> None:
        """Most popular movies."""
        # FF: primary_release_date.lte=%s&sort_by=popularity.desc
        self.discover(page=page, sort_by='popularity.desc', primary_release_date=tmdb.Date <= self.today())

    @route
    def top_rated(self, *, page: PathArg[int] = 1) -> None:
        """Top rated movies."""
        # TMDB API: sort_by=vote_average.desc&without_genres=99,10755&vote_count.gte=200'
        filters: DiscoveryFilters = {
            'sort_by': 'vote_average.desc',
            'without_genres': '99,10755',
            'primary_release_date': tmdb.Date <= self.not_so_today(),
        }
        if vote_count := const.indexer.movies.top_rated.votes:
            filters['vote_count'] = tmdb.VoteCount >= vote_count
        self.discover(page=page, **filters)

    @route
    def new(self, *, page: PathArg[int] = 1) -> None:
        """Latest movies list."""
        # FF: sort_by=primary_release_date.desc&primary_release_date.lte=%s&vote_count.gte=%s
        self.discover(page=page, sort_by='primary_release_date.desc', primary_release_date=tmdb.Date <= tmdb.Today,
                      votes=const.indexer.movies.new.votes)

    @route
    def cinema(self, *, page: PathArg[int] = 1) -> None:
        """In Theaters (in cinema)."""
        # FF: sort_by=primary_release_date.desc&release_date.gte=%s&release_date.lte=%s&with_release_type=3&vote_count.gte=%s
        today = self.today()
        old = today - timedelta(days=const.indexer.movies.cinema.last_days)
        today += timedelta(days=const.indexer.movies.cinema.next_days)
        filters: DiscoveryFilters = {
            'sort_by': 'primary_release_date.desc',
            'with_release_type': 3,
            'release_date': tmdb.Date.range(old, today),
        }
        if const.indexer.movies.cinema.use_region and const.indexer.region:
            filters['watch_region'] = const.indexer.region
        self.discover(page=page, **filters)

    @route('tv/{service}')
    @route('tv')
    def tv(self, service: Optional[TvServiceName] = None, *, page: PathArg[int] = 1) -> None:
        """Today in TV."""
        def add_tv(kdir: KodiDirectory, tv: 'TvMovie') -> None:
            kdir.folder(tv.title, url_for(self.tv_filmweb, service=service, entry_id=tv.id),
                        thumb=tv.image or 'DefaultMovies.png', descr=tv.descr, role=tv.role())

        if service is None:
            service = const.indexer.movies.tv.service
        if not (common := TvProgram.tv_service(service=service)):
            return self.no_content()
        mode = const.indexer.movies.tv.list_mode
        size = const.indexer.movies.tv.page_size
        fflog(f'In TV: {service=}, {mode=}, {page=}, page_size={size}')
        if not size:
            size = 1_000_000_000
        if mode == 'media':
            self.show_items(common.tv_movie_all_items(page=page, limit=size))
        elif mode == 'mixed':
            movies = common.tv_movie_mixed_items(page=page, limit=size)
            with directory(movies, view='movies') as kdir:
                for it in movies:
                    if isinstance(it, FFItem):
                        self.show_item(kdir, it)
                    else:
                        add_tv(kdir, it)
        elif mode == 'folders':
            movies = common.tv_movies(page=page, limit=size)
            with directory(movies, view='movies') as kdir:
                for tv in movies:
                    add_tv(kdir, tv)
        else:
            self.no_content()

    @route('/tv/{service}/{entry_id}')
    def tv_filmweb(self, service: TvServiceName, entry_id: str, *, page: PathArg[int] = 1) -> None:
        """Today in TV."""
        if not (common := TvProgram.tv_service(service=service)):
            return self.no_content()
        self.show_items(common.tv_movie_items(entry_id))

    @route
    def boxoffice(self) -> None:
        """Box office."""
        items = trakt.box_office()
        self.show_items(items)

    def awards_folder(self) -> None:
        """Create main awards menu. Must be called from @route, eg. awards()."""
        with directory(thumb='oscar-winners.png') as kdir:
            kdir.folder(L(30166, 'Oscar Winner'), url_for(name='oscar_winner'))
            kdir.folder(L(30167, 'Oscar Nominee'), url_for(name='oscar_nominee'))
            kdir.folder(L(30168, 'Oscar Best Picture Winner'), url_for(name='best_picture_winner'))
            kdir.folder(L(30169, 'Oscar Best Picture Nominee'), url_for(name='oscar_best_picture_nominees'))
            kdir.folder(L(30170, 'Oscar Best Director Winner'), url_for(name='best_director_winner'))
            kdir.folder(L(30171, 'Oscar Best Director Nominee'), url_for(name='oscar_best_director_nominees'))
            kdir.folder(L(30172, 'Razzie Winner'), url_for(name='razzie_winner'), thumb='razzie_winners.png')
            kdir.folder(L(30173, 'Razzie Nominee'), url_for(name='razzie_nominee'), thumb='razzie_winners.png')
            kdir.folder(L(30174, 'Emmy Nominee'), url_for(name='emmy_nominee'), thumb='awards.png')

    @route
    def awards(self, name: Optional[PathArg[str]] = None, page: PathArg[int] = 1) -> None:
        """Last 250 oscars"""
        if name:
            return self.awards_media(name, page=page, title_type='feature')  # feature = movies
        return self.awards_folder()

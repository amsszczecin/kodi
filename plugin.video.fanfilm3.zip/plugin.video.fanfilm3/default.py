"""
    FanFilm Add-on
    Copyright (C) 2016 mrknow

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import sys
from time import monotonic

# debug
_start_time: float = monotonic()

# MUST be before any kodi or FF import
from lib import autoinstall  # noqa: E402, F401, pylint: disable=W0611  # type: ignore
# Some consts.
from const import const, run_debugger         # noqa: E402
from lib.preenter import preinit, premain     # noqa: E402
from lib.service.exc import ReloadExit        # noqa: E402

try:
    preinit()
except ReloadExit:
    # -- reload on source file chnged
    import xbmc
    import xbmcgui
    xbmc.log("[FanFilm][default.py][dev] change detected, force exit...", xbmc.LOGINFO)
    xbmcgui.Dialog().notification("[FanFilm][dev]", "FanFilm reload, force exit")
    sys.exit()

from lib.ff.log_utils import fflog            # noqa: E402
from lib.main import main, new_run, reset     # noqa: E402

# count run calls
run_count: int = new_run()

# debug
if const.debug.enabled:
    import os
    import threading
    pid = os.getpid()
    tid = threading.get_ident()
    if const.debug.tty:
        yellow, yellow_bold, off = '\033[93m', '\033[93;1m', '\033[0m'
    else:
        yellow = yellow_bold = off = ''
    fflog(f"{yellow_bold}[FF]{off} {yellow}enter{off} [{pid}:{tid}:{yellow}{run_count}{off}] {sys.argv=}")
if const.debugger.enabled:
    run_debugger()

# reset some stuff on script relaod
reset()


try:
    premain()
    main(sys.argv)
finally:
    exit_every_nth = const.core.exit_every_nth
    if const.debug.enabled:
        T: float = monotonic() - _start_time
        exit_mode = ''
        if exit_every_nth and run_count >= exit_every_nth:
            exit_mode = ' (sys)'
        fflog(f'{yellow}[FF] exit{exit_mode}{off} [{pid}:{tid}:{yellow}{run_count}{off}] --- ({T:.3f}s)')
    # Script exit to force python interpreter reload
    if exit_every_nth and run_count >= exit_every_nth:
        sys.exit()
